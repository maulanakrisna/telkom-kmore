<?php
// Show member of Portal
/*
Are you using SQL Server 2005 Express? Don't miss the server name syntax Servername\SQLEXPRESS 
where you substitute Servername with the name of the computer where the SQL Server 2005 Express installation resides.

Standard security:
Driver={SQL Native Client};Server=myServerAddress;Database=myDataBase;Uid=myUsername;Pwd=myPassword;
*/

// RDCDB - OK!
$dbtype  = "ado_mssql";
$dbhost  = "10.14.0.64\rdcdb";
$dbuser  = "ip";
$dbpass  = "telkomrdc";
$dbname  = "member";
$dbtable = "v_WargaRistiNew";

/*
(3) Email
(4) id
(0) IDUser
(6) JobTitle
(5) LastLogin
(1) NamaLengkap
(2) NIK
(7) Posisi
(9) UnitKerja
(8) UnitKerjaDesc
*/

include('include/adodb.inc.php');
ADOLoadCode($dbtype);
$db = &ADONewConnection($dbtype);
$myDSN="PROVIDER=MSDASQL;DRIVER={SQL Server};"."SERVER=".$dbhost.";DATABASE=".$dbname.";UID=".$dbuser.";PWD=".$dbpass.";"  ;
$db->Connect($myDSN);

#$rs = $db->Execute("SELECT * FROM v_WargaRistiNew ORDER BY NamaLengkap ASC");
$rs = $db->Execute("SELECT * FROM v_WargaRistiNew ORDER BY LastLogin DESC");
if (!$rs)
	print $conn->ErrorMsg();
else {
?>
<html>
<head>
<title>ADOdb (Apache on Windows)</title>
<style type="text/css">
td { border-style: solid;
	padding: 0 4;
	font-family: arial;
	font-size: 10pt; }
</style>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" width=800>

<?
	print "<h1>POINT User ID...</h1>";
	print "<h3>KMORE DITS Server - Connecting <font color=\"blue\">RDCDB</font> (MS SQL Server) using ADOdb via Apache (Windows)</h3>";
	
    print "Result is:<P>";
	print "<table border=1 cellspacing=0 cellpadding=0 width=800>";
	print "<tr align=\"center\" bgcolor=\"#F0F0F0\"><td>No.</td><td>NIK</td><td>Nama</td><td>Loker</td><td>ID Session</td></tr>";
	$i = 1;
	while (!$rs->EOF) {
		$info = explode('/', $rs->fields[1]);
		print '<tr valign="top"><td align=right>'.$i.'.</td>';
		print '<td>'.$rs->fields[2].'</td><td>'.$info[0].'</td>';
		print '<td>'.$rs->fields[8].'</td>';
		print '<td><a href="http://10.14.0.84/kmore/?id='.$rs->fields[4].'">'.substr($rs->fields[4],0,25).'...</a></td>';
		print '</tr>';
		$i++;
		$rs->MoveNext();
	}
	print "</table>";
}
$rs->Close(); # optional
$db->Close(); # optional

?>
</body>
</html>
