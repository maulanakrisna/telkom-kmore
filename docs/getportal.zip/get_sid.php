<?
// Show member of Portal
/*
Are you using SQL Server 2005 Express? Don't miss the server name syntax Servername\SQLEXPRESS 
where you substitute Servername with the name of the computer where the SQL Server 2005 Express installation resides.

Standard security:
Driver={SQL Native Client};Server=myServerAddress;Database=myDataBase;Uid=myUsername;Pwd=myPassword;
*/

// RDCDB - OK!
$dbtype  = "ado_mssql";
$dbhost  = "10.14.0.64\rdcdb";
$dbuser  = "ip";
$dbpass  = "telkomrdc";
$dbname  = "member";
$dbtable = "v_WargaRistiNew";

/*
(3) Email
(4) id
(0) IDUser
(6) JobTitle
(5) LastLogin
(1) NamaLengkap
(2) NIK
(7) Posisi
(9) UnitKerja
(8) UnitKerjaDesc
*/

include('include/adodb.inc.php');
ADOLoadCode($dbtype);
$db = &ADONewConnection($dbtype);
$myDSN="PROVIDER=MSDASQL;DRIVER={SQL Server};"."SERVER=".$dbhost.";DATABASE=".$dbname.";UID=".$dbuser.";PWD=".$dbpass.";"  ;
$db->Connect($myDSN);

$rs = $db->Execute("SELECT * FROM v_WargaRistiNew ORDER BY LastLogin DESC");
if (!$rs)
	print $conn->ErrorMsg();
else {
	include("include/dbcon.php");
	$q = "SELECT nik FROM v_wargaristinew";
	query_sql($q,$r);
	$n = mysql_num_rows($r);
	if ($n == 0)
		echo "Create table<br>";
	else
		echo "Update table<br>";

	while (!$rs->EOF) {
		$info = explode('/', $rs->fields[1]);
		$nama = str_replace("'", "''", $info[0]);
		$dates = date("Y-m-d H:i:s",strtotime($rs->fields[5]));

		if ($n == 0)
			$q = "INSERT INTO v_wargaristinew (nama, nik, email, last_login, loker, session_id) VALUES ('".$nama."', '".$rs->fields[2]."', '".$rs->fields[3]."', '".$dates."', '".$rs->fields[8]."', '".$rs->fields[4]."')";
		else
			$q = "UPDATE v_wargaristinew SET last_login='".$dates."', loker='".$rs->fields[8]."', session_id='".$rs->fields[4]."' WHERE nik='".$rs->fields[2]."'";
		echo "$q<br>";
		query_sql($q,$r);
		$rs->MoveNext();
	}
}
$rs->Close(); # optional
$db->Close(); # optional

$q


?>