<?php
// Show member of Portal
/*
Are you using SQL Server 2005 Express? Don't miss the server name syntax Servername\SQLEXPRESS 
where you substitute Servername with the name of the computer where the SQL Server 2005 Express installation resides.

Standard security:
Driver={SQL Native Client};Server=myServerAddress;Database=myDataBase;Uid=myUsername;Pwd=myPassword;
*/

// RDCDB - OK!
$dbtype  = "ado_mssql";
$dbhost  = "10.14.0.64\rdcdb";
$dbuser  = "ip";
$dbpass  = "telkomrdc";
$dbname  = "member";
$dbtable = "v_WargaRistiNew";

/*
(3) Email
(4) id
(0) IDUser
(6) JobTitle
(5) LastLogin
(1) NamaLengkap
(2) NIK
(7) Posisi
(9) UnitKerja
(8) UnitKerjaDesc
*/
?>
<html>
<head>
<title>ADOdb (Apache on Windows)</title>
<style type="text/css">
td { border-style: solid;
	padding: 0 4;
	font-family: arial;
	font-size: 9pt; }
</style>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" width=800>
<?
print "<h1>POINT User Login...</h1>";
print "<h3>Connecting <font color=\"blue\">RDCDB</font> (MS SQL Server) using ADOdb via Apache (Windows)</h3>";

include('include/adodb.inc.php');
ADOLoadCode($dbtype);
$db = &ADONewConnection($dbtype);
$myDSN="PROVIDER=MSDASQL;DRIVER={SQL Server};"."SERVER=".$dbhost.";DATABASE=".$dbname.";UID=".$dbuser.";PWD=".$dbpass.";"  ;
$db->Connect($myDSN);

$rs = $db->Execute("SELECT * FROM v_WargaRistiNew ORDER BY LastLogin DESC");
#$rs = $db->Execute("SELECT * FROM v_WargaRistiNew ORDER BY nik DESC");
#$rs = $db->Execute("SELECT * FROM v_WargaRistiNew ORDER BY NamaLengkap");
if (!$rs)
	print $conn->ErrorMsg();
else {
    print "Result is:<P>";
	print "<table border=1 cellspacing=0 cellpadding=1 width=900>";
	print "<tr bgcolor=\"#F0F0F0\" align=\"center\"><td>No.</td><td>NIK</td><td>Nama/Email</td><td>Last Login</td><td>Bidang</td><td>Session ID</td></tr>";
	#print "<tr bgcolor=\"#F0F0F0\" align=\"center\"><td>No.</td><td>NIK</td><td>Nama</td><td>Last Login</td><td>Bidang</td></tr>";
	print "<tr bgcolor=\"#F0F0F0\" align=\"center\"><td>\$i</td><td>fields[2]</td><td>fields[1]/fields[3]</td><td>fields[5]</td><td>fields[8]</td><td>fields[4]</td></tr>";
	#print "<tr bgcolor=\"#F0F0F0\" align=\"center\"><td>\$i</td><td>fields[2]</td><td>fields[1]</td><td>fields[5]</td><td>fields[8]</td></tr>";
	$i = 1;
	while (!$rs->EOF) {
		$info = explode('/', $rs->fields[1]);
		print "<tr valign=\"top\">";
		#print "<td>".$i."</td><td>".$rs->fields[2].'</td><td>'.$info[0].'</td><td>'.$rs->fields[5].'</td><td>'.date('d-m-Y H:i:s',$rs->fields[5]).'</td>';
		print "<td align=right>".$i."</td><td>".$rs->fields[2].'</td><td>'.$info[0].'<br>'.$rs->fields[3].'</td><td>'.$rs->fields[5].'</td><td>'.$rs->fields[8].'</td><td><a href="http://10.14.0.84/kmore/?id='.$rs->fields[4].'">'.substr($rs->fields[4],0,25).'...</a></td>';
		#print "<td>".$i."</td><td>".$rs->fields[2].'</td><td>'.$info[0].'</td><td>'.$rs->fields[5].'</td><td>'.$rs->fields[8].'</td>';
		print "</tr>";
		$rs->MoveNext();
		$i++;
	}
	print "</table>";
}
$rs->Close(); # optional
$db->Close(); # optional

?>
</body>
</html>
