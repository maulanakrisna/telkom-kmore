<?
$q = "SELECT * FROM loker WHERE id_loker='$_REQUEST[idl]'";
#echo "$q<br>";
$result = mysql_query($q);
$rows = mysql_fetch_object($result);
?>

<br>
	<form name="myform" class="cmxform" id="commentForm" action="save2db.php" method="post">
		<fieldset>
			<h2>Add Knowledge Map</h2>
			<p>
				<label for="clevel1">Level 1:</label>
				<input type="text" id="clevel1" name="level1" size="3" readonly value="<?= $rows->id_loker; ?>"/>
			</p>
			<p>
				<label for="clevel2">Level 2:&nbsp;*</label>
				<input type="text" id="clevel2" name="level2" size="100" maxlength="100" class="required" value="<?= $rows->nm_loker; ?>"/>
			</p>
			<p>
				<label for="cid_map">ID:</label>
				<input type="text" id="cid_map" name="id_map" size="6" maxlength="6" value="<?= $rows->acronym; ?>"/>
			</p>
			<p>
				<label for="cnm_map">Knowledge Map:</label>
				<input type="text" id="cnm_map" name="nm_map" size="50" maxlength="50" class="required"/>
			</p>
			<p>
				<label for="cexpert">Knowledge Map:</label>
				<input type="text" id="cexpert" name="expert" size="50" maxlength="50"/>
			</p>
			<p>
				<label>&nbsp;</label><input type="submit" name="btnSubmit" class="submit" value="Submit"/>&nbsp;
				<input type="hidden" name="sw" value="67">
			</p>
