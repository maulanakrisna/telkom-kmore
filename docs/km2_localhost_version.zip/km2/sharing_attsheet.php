<?php
session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>KMORE - Attendance Sheet</title>
<meta name="Generator" content="EditPlus">
<meta name="Author" content="">
<meta name="Keywords" content="">
<meta name="Description" content="">
<link type="text/css" href="style/master.css" rel="stylesheet"/>
<!--
<script language="javascript">
function thickboxDone() {
 TB_remove();
}
</script>
-->
<style type="text/css">
table tr td {
	vertical-align: top;
	border: 0px solid #408080;
}
td {
	padding: 0 3;
}
h2 {
	padding: 0 auto;
	text-align: center;
}
.mycolor {
	background: #A9D3BB;
}
.mycolor2 {
	background: #F2F2F2;
a.thick:link { text-decoration: none; color: #0000FF; }
a.thick:visited { text-decoration: none; color: #0000FF; }
a.thick:hover { text-decoration: underline; color: #FF0000; }
a.confirm:link { text-decoration: none; color: #0000FF; }
}
</style>
</head>
<body>
<?
require_once ("include/dbcon.php");
if (isset($_REQUEST[sw]))
{
	$nik_attend = "'".implode("','",$_REQUEST[attend])."'";
	$q = "UPDATE sharing_activity SET attend='1' WHERE id_know='$_REQUEST[idk]' AND nik IN ($nik_attend)";
	query_sql($q,$res);
}
// Step 1
$judul = "Sharing Knowledge Attendance Sheet";

// Step 2
$query = "SELECT a.*,b.nama,c.nm_loker,d.nm_confirm FROM sharing_activity a JOIN user b ON a.nik=b.nik JOIN loker c ON b.id_bidang=c.id_loker JOIN confirm d ON a.id_confirm=d.id_confirm WHERE id_know='$_REQUEST[idk]' AND a.id_confirm BETWEEN '1' AND '2' ORDER BY a.id_inv_status,c.id_loker,b.nik";
#echo "$query<br>";
query_sql($query,$result);
$num = mysql_num_rows($result);

$query = "SELECT a.*,b.nama,c.nm_loker,d.nm_confirm FROM sharing_activity a JOIN user b ON a.nik=b.nik JOIN loker c ON b.id_bidang=c.id_loker JOIN confirm d ON a.id_confirm=d.id_confirm WHERE id_know='$_REQUEST[idk]' ORDER BY a.id_inv_status,c.id_loker,b.nik";
#echo "$query<br>";
query_sql($query,$result);

#echo "<table class='spacer' width='750' border='0'><tr><td><h3>$judul</h3></td><td align='right' style='padding-right:2px'>Page: $pageNum</td></tr>";
echo "<h3>$judul</h3>";
echo "Confirmed: $num ";

# print table header
echo "<form action='' method='post'>";
echo "<table id='myTable' class='tablesorter' border='0' cellpadding='0' cellspacing='1'>";
echo "<thead><tr><th>No.</th><th>NIK</th><th>Nama</th><th>Bidang</th><th>Confirm</th><th>Attend</th></tr></thead>";
echo "<tbody>";

# print table rows
$no =  $offset+1;
while ($row = mysql_fetch_array($result))
{
?>
	<tr valign="top">
		<td align="right" width="10px"><?= $no; ?>.</td>
		<td><?= $row["nik"]; ?></td>
		<td><?= $row["nama"]; ?></td>
		<td><?= $row["nm_loker"]; ?></td>
		<td><?= $row["nm_confirm"]; ?></td>
		<td><input type="checkbox" id="cattend[]" name="attend[]" value="<?= $row["nik"]; ?>" <? if ($row["attend"]==1 && $row["nik"]==$_SESSION["nik_login"]) echo 'checked disabled'; ?>></td>
	</tr>
<?
	$no++;
}
echo "</tbody>";
echo "<input type='hidden' name='idk' value='$_REQUEST[idk]'>";
echo "<input type='hidden' name='sw' value='20'>";
echo "<tr align='center'><td colspan='6'><input type='submit' name='submit' value='Submit'></td></tr>";
echo "</form>";
echo "</table>";
?>
</body>
</html>
