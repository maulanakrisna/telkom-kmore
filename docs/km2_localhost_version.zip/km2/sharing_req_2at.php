<?
/*
-----
file asal  : sharing_schedule.php, sharing_req_his.php, newsticker.php
file tujuan: save2db.php?sw=16
-----
*/
session_start();
/*
if (!isset($_SESSION['nik_login']))
{
	Header("Location:login.php");
}
*/

// Step 1
$judul = "Request To Attend";
require_once ("include/dbcon.php");

// get sharing's title
$query = "SELECT a.judul, a.inv_bidang, a.nik, b.id_bidang, c.nm_bidang FROM knowledge a JOIN sharing_activity b ON a.nik=b.nik AND a.id_know=b.id_know JOIN bidang c ON b.id_bidang=c.id_bidang WHERE a.id_know='$_REQUEST[idk]'";
#echo "$query<br>";
query_sql($query,$result);
$rows = mysql_fetch_array($result);

// get invited bidang
// e.g. "140,150,160"
$inv_bid = $rows[inv_bidang];
$find_bid = str_replace(",", "','",$inv_bid);
#echo "\$find_bid:$find_bid<br>";

$nm_bidang = array();
$q = "SELECT nm_bidang FROM bidang WHERE id_bidang IN ('$find_bid')";
#echo "\$q: $q<br>";
$res = mysql_query($q);
while ($r = mysql_fetch_array($res))
{
	$nm_bidang[] = $r[nm_bidang];
}
$inv_bid = implode(", ",$nm_bidang);

echo "<table>";
echo "<tr><td valign='top'>Title:</td><td>$rows[judul]</td></tr>";
echo "<tr><td valign='top'>Audience:&nbsp;</td><td>$inv_bid</td></tr><br>";
echo "</table>";

// Step 2
// who has requested to attend
$query = "SELECT a.*,b.nama,c.nm_loker,d.nm_confirm FROM sharing_activity a JOIN user b ON a.nik=b.nik JOIN loker c ON b.id_bidang=c.id_loker JOIN confirm d ON a.id_confirm=d.id_confirm WHERE a.nik<>'$_SESSION[nik_login]' AND id_know='$_REQUEST[idk]' AND a.id_inv_status = '4' ORDER BY a.id_inv_status,c.id_loker,b.nik";
#echo "$query<br>";
query_sql($query,$result);
$num = mysql_num_rows($result);

if ($num <> 0)
{
	#echo "<table class='spacer' width='750' border='0'><tr><td><h3>$judul</h3></td><td align='right' style='padding-right:2px'>Page: $pageNum</td></tr>";
	echo "<table class='spacer' width='580' border='0'><tr><td colspan='2'><h3>$judul</h3></td></tr>";

	# print table header
	echo "<table id='myTable' width='580' class='tablesorter' border='0' cellpadding='0' cellspacing='1'>";
	echo "<thead><tr><th>No.</th><th>NIK</th><th>Nama</th><th>Bidang</th><th>Confirmation</th></tr></thead>";
	echo "<tbody>";

	# print table rows
	$no =  $offset+1;
	while ($row = mysql_fetch_array($result))
	{
?>
	<tr valign="top">
		<td align="right" width="10px"><?= $no; ?>.</td>
		<td><?= $row["nik"]; ?></td>
		<td><?= $row["nama"]; ?></td>
		<td><?= $row["nm_loker"]; ?></td>
		<td><?= $row["nm_confirm"]; ?></td>
	</tr>
<?
		$no++;
	}
	echo "</tbody>";
	echo "</table><p>";
}
else
{		
	echo "<br><br><br><br><center>There's no request to attend my sharing knowledge</center>";
}
echo "<br><center><input type='submit' name='submit' value='Close' onclick='tb_remove()'></center>";
?>
