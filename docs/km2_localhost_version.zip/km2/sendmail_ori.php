<?php
// http://www.askapache.com/php/phpfreaks-eric-rosebrocks-phpmailer-tutorial.html
require_once('include/dbcon.php');

// Grab our config settings
require_once('libs/config.php');
 
// Grab the FreakMailer class
require_once('libs/MailClass.inc');
 
// instantiate the class
$mailer = new FreakMailer();

// Set sender
$mailer->FromName = $name; //'Your Name';
$mailer->From = $email; //'You@yourdomain.com';

// Get the subject from subject table
$q = "SELECT nm_subject,message,message2 FROM subject WHERE id_subject='$ids'";
echo "$q<br>---<br>";
$result = mysql_query($q);
$rows = mysql_fetch_object ($result);
$subject = $rows->nm_subject;

switch ($ids)
{	// refer to subject table
	case "1" :
		// Request Sharing
		$message  = "$name ($nik) ".$rows->message;
		$message .= "<br>judul: <strong>$judul</strong>";
		$message .= "<br>".$rows->message2;
		break;
	case "4" :
		// Request to Attend
		$message  = "$name ($nik) dari bidang $bid ".$rows->message;
		$message .= "<br>judul: <strong>$judul</strong>";
		$message .= "<br>".$rows->message2;
		break;
	case "7" :
		// Sharing Invitation
		$message  = "$name ($nik) ".$rows->message;
		$message .= "<br>judul: <strong>$judul</strong><br>pada tanggal $tgl, mulai jam".$jam1." s/d ".$jam2;
		$message .= " tempat: $lokasi<br>".$rows->message2;
		break;
	case "8" :
		// Closing Report Request
		$message  = "$name ($nik) ".$rows->message;
		$message .= "<br>judul: <strong>$judul</strong>";
		$message .= "<br>".$rows->message2;
		break;
}

// Set the subject
$mailer->Subject = $subject;
 
// Body
$mailer->Body = $message;
 
// Get recipient(s) from user table
switch ($ids)
{	// refer to subject table
	case "1" :
		// Request Sharing
		#$q = "SELECT nama,email FROM user_test WHERE id_bidang='$idb' AND id_profile < 3";
		$q = "SELECT nama,email FROM user WHERE id_bidang='$idb' AND id_profile < 3";
		echo "$q<br>";
		break;
	case "4" :
		// Request to Attend
		#$q = "SELECT nama,email FROM user_test WHERE id_bidang='$idb' AND id_profile < 3";
		$q = "SELECT nama,email FROM user WHERE id_bidang='$idb' AND id_profile < 3";
		#echo "$q<br>";
		break;
	case "7" :
		// Sharing Invitation
		$inv_bid = implode("','",$bid);
		#$q = "SELECT nm_bidang,email FROM bidang_test WHERE id_bidang in ('$inv_bid')";
		$q = "SELECT nm_bidang,email FROM bidang WHERE id_bidang in ('$inv_bid')";
		#echo "$q<br>";
		break;
	case "8" :
		// Closing Report Request
		#$q = "SELECT nama,email FROM user_test WHERE id_bidang='$idb' AND id_profile < 3";
		$q = "SELECT nama,email FROM user WHERE id_bidang='$idb' AND id_profile < 3";
		#echo "$q<br>";
		break;
}
// Tester
#echo "Subject: $subject<br>";
#echo "From: $name &lt;$email&gt;<br>";

$ccs = "";
$x=1;
$result = mysql_query($q);
while ($rows = mysql_fetch_object ($result))
{
	if ($ids==1 || $ids==8) $rcp_name = $rows->nama; else $rcp_name = $rows->nm_bidang;
	$rcp_email = $rows->email;
	if ($x==1)
	{
	// Add an address to send to.
		$mailer->AddAddress($rcp_email, $rcp_name); // recipient's email & name
		echo "To: $rcp_name &lt;$rcp_email&gt;<br>";
	}
	else
	{
	// Add CC address.
		$mailer->AddCC($rcp_email, $rcp_name); // CC's email & name
		$ccs .= "$rcp_name &lt;$rcp_email&gt;, ";
	}
	$x++;
}
if ($ids==7)
{
	if (isset($external))
	{
		foreach ($external as $key => $value)
		{
			$mailer->AddCC($value, ""); // CC's email & name
			$ccs .= "$rcp_name &lt;$value&gt;, ";
		}
	}
}

if (mysql_num_rows($result)>1)
{
	$ccs = substr($ccs,0,strlen($ccs)-1);
	echo "CC: $ccs<br>";
}
echo "Message:<br>$message<br>";

$mailer->isHTML(true);

/* Tester
if(!$mailer->Send())
{
    echo '<strong>There was a problem sending this mail!</strong>';
}
else
{
    #echo 'Mail sent!';
}
*/
$mailer->ClearAddresses();
$mailer->ClearAttachments();
?>