<h3>About KMORE</h3>

<br>Aplikasi KMORE (Knowledge Management Report On-Line) merupakan sebuah aplikasi berbasis web yang terintegrasi dengan portal RDC, yang digunakan sebagai sarana pendukung untuk melakukan pengelolaan terhadap aktivitas knowledge management (KM), dengan penggunanya adalah seluruh Warga RDC.

<br><br>Proses utama yang dikelola oleh aplikasi ini adalah antara lain mencatatkan setiap event atau aktivitas penyelenggaraan sharing KM, mulai dari submit request sharing KM, mengisikan report hasil sharing, mengambil (retrieving) data hasil sharing KM yang sudah pernah dilakukan, dan menampilkan reporting dan rekapitulasi sharing KM beserta nilainya secara periodik dan fungsi admin. Dengan aplikasi KMORE ini sebagai alat bantu maka diharapkan proses kegiatan KM di lingkungan RDC dapat ditingkatkan baik dari sisi kuantitas maupun kualitas.
