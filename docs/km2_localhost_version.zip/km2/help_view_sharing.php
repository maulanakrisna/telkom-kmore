<h3>View Sharing</h3>

<br><b>Melihat Sharing</b>
<br>Setiap Sharing Knowledge yang telah terjadwal dapat dilihat di menu Home.
<br>Langkah-langkah yang harus dilakukan sbb:
<ul class="report">
<li>Klik Sharing > Close Sharing Task
<li>Klik link judul sharing yang akan ditutup
<li>Lengkapi data-data yang diperlukan
<li>Tambahkan file-file yang akan di-upload
<li>Jika form sudah terisi, tekan tombol submit
<li>Selanjutnya layar akan menampilkan daftar My Sharing Knowledge dengan status Closing yang artinya menunggu persetujuan laporan sharing dari Committee.
</ul>

<br>Jika laporan sharing telah disetujui, maka sharing tersebut dapat dilihat di menu Home > Archives.

