<?
session_start();

// http://www.askapache.com/php/phpfreaks-eric-rosebrocks-phpmailer-tutorial.html
include('include/dbcon.php');

// Grab our config settings
include('libs/config.php');
 
// Grab the FreakMailer class
include('libs/MailClass.inc');

// --- Submitter: Create New Request Sharing Knowledge
// call from: req_fill_in.php
// Status: Running

include ("include/convertdatetime.php");
$t_mulai = date("Y-m-d H:i:s", strtotime($_REQUEST["start-date"]." ".$_REQUEST[jmulai].":".$_REQUEST[mmulai]));
$t_akhir = date("Y-m-d H:i:s", strtotime($_REQUEST["start-date"]." ".$_REQUEST[jusai].":".$_REQUEST[musai]));

// Check if date is conflict with sharing schedule
$q  = "SELECT id_know,t_mulai,t_akhir FROM knowledge WHERE sharing_status='3' AND ";
$q .= "((t_mulai BETWEEN '$t_mulai' AND '$t_akhir') OR (t_akhir BETWEEN '$t_mulai' AND '$t_akhir')) LIMIT 1";
echo $q;
query_sql($q,$r);
$n = mysql_num_rows($r);
if ($n > 0) {
	$conflict = 1;
} else {
	// Check if date is conflict with sharing request
	$q  = "SELECT id_know,t_mulai,t_akhir FROM knowledge WHERE sharing_status='1' AND ";
	$q .= "((t_mulai BETWEEN '$t_mulai' AND '$t_akhir') OR (t_akhir BETWEEN '$t_mulai' AND '$t_akhir')) LIMIT 1";
	echo $q;
	query_sql($q,$r);
	$n = mysql_num_rows($r);
	if ($n > 0) {
		$conflict = 2;
	} else {
		$conflict = 0;
	}
}

// get member of speaker
$bid = $_REQUEST[niklain];
$niklain = array();
foreach ($bid AS $key => $value) {
	if (strlen($value)>0)
		$niklain[] = $value;
}
$member = implode(",",$niklain);

// get nik & bidang
$bid = $_REQUEST[bidang];
$inv_bidang = implode(",",$bid);
#echo "\$inv_bidang: $inv_bidang<br>";

$your_nik  = explode("-",$_REQUEST['nik']);
// save to knowledge table
$q="INSERT INTO knowledge (submitter, nik, member, id_map, jenis, judul, t_mulai, t_akhir, lokasi, unitkerja, inv_bidang, ext_audience, ext_instance, abstraksi, harapan, referensi, created, conflict) VALUES ( '$_SESSION[nik_login]', '$your_nik[0]', '$member', '$_REQUEST[id_map]', '$_REQUEST[jenis]', '$_REQUEST[judul]', '$t_mulai', '$t_akhir', '$_REQUEST[lokasi]', '$_REQUEST[unitkerja]', '$inv_bidang', '$_REQUEST[exaudien]', '$_REQUEST[exinstance]', '$_REQUEST[abstraksi]', '$_REQUEST[harapan]', '$_REQUEST[referensi]', NOW(), '$conflict')";
echo "$q<br>";
#query_sql($q,$res);

// get knowledge that just inserted
$q="SELECT a.id_know,a.nik,a.judul,a.lokasi,b.nama,b.email,b.id_bidang FROM knowledge a JOIN user b ON a.nik=b.nik ORDER BY id_know DESC LIMIT 1"; 
#echo "<br>==>&nbsp;$q<br>";
$result  = mysql_query($q);
$rows    = mysql_fetch_object ($result);
$id_know = $rows->id_know;
$nik     = $rows->nik;
$name    = $rows->nama;
$email   = $rows->email;
$judul   = $rows->judul;
$lokasi  = $rows->lokasi;
$tgl     = date("d-m-Y",strtotime($t_mulai));
$jam1    = date("H:i",strtotime($t_mulai));
$jam2    = date("H:i",strtotime($t_akhir));
$idb     = $rows->id_bidang;
$ids     = 1;
$nik_sgm = ""; $external = "";

// send notification by e-mail
require_once("sendmail_test.php");
sending($ids,$idb,$bid,$external,$nik,$name,$email,$judul,$lokasi,$tgl,$jam1,$jam2,$nik_sgm);

Header("Location: sharing.php?mn=1&id=$_SESSION[sid]");
break;
?>