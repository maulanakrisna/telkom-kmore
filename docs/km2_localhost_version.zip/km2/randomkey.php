<?
include("include/fgenkey.php");
$insert_key = gen_key();
echo "\$insert_key: $insert_key";

?>