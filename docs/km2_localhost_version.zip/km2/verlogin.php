<?
#require_once("include/dbcon.php");
if (!empty($_REQUEST['id']))
	$sesid = $_REQUEST['id'];
else
	$sesid = $_SESSION['sid'];
$sQuery = "SELECT * FROM v_wargaristi WHERE id='$sesid'";
#echo $sQuery."<br>";
$result = mysql_query($sQuery);
$row = mysql_fetch_object($result);

if (mysql_num_rows($result)>0) {
	#session_start();
	if (!empty($_REQUEST['id']))
		$_SESSION['sid'] = $_REQUEST['id'];
	$_SESSION['nik'] = $row->NIK;

	$sQuery = "SELECT a.nik, a.nama, a.id_profile, a.id_bidang, b.nm_profile, c.nm_loker FROM user AS a JOIN profile b ON a.id_profile=b.id_profile JOIN loker c ON a.id_loker=c.id_loker WHERE a.nik ='".$_SESSION['nik']."'";
	#echo $sQuery."<br>";
	$result = mysql_query($sQuery);
	$row = mysql_fetch_object($result);
	
	if (mysql_num_rows($result)>0) {
		session_start();
		$_SESSION['nik_login'] = $row->nik;
		$_SESSION['nik'] = $row->nik;
		$_SESSION['nama'] = $row->nama;
		$_SESSION['email'] = $row->email;
		$_SESSION['id_bidang'] = $row->id_bidang;
		$_SESSION['id_loker'] = $row->id_loker;
		$_SESSION['nm_loker'] = $row->nm_loker;
		$_SESSION['id_profile'] = $row->id_profile;
		$_SESSION['nm_profile'] = $row->nm_profile;
	} else {
		echo "Data not found!<br>";
	}
}

?>