<?
	case "21" :
		// --- Committee: Sharing Knowledge Approval
		// call from: mgm_req_review.php
		// Status: Running
		include ("include/convertdatetime.php");
		$t_mulai = date("Y-m-d H:i:s", strtotime($_REQUEST["start-date"]." ".$_REQUEST[jmulai].":".$_REQUEST[mmulai]));
		$t_akhir = date("Y-m-d H:i:s", strtotime($_REQUEST["start-date"]." ".$_REQUEST[jusai].":".$_REQUEST[musai]));

		if ($_REQUEST[approval]==0) {
			$q  = "UPDATE knowledge SET t_mulai='$t_mulai', t_akhir='$t_akhir', lokasi='$_REQUEST[lokasi]', ";
			$q .= "sharing_status='2', app_req_by='$_SESSION[nik_login]', app_req_at=NOW() WHERE id_know='$_REQUEST[idk]'";
			#echo "$q<br>-----<br>";
			query_sql($q,$res);

			if (strlen($_REQUEST[catatan])>0) {
				$q  = "INSERT INTO sharing_notes (id_know, nik, created, notes) VALUES ";
				$q .= "('$_REQUEST[idk]', '$_SESSION[nik_login]', NOW(), '$_REQUEST[catatan]')";
				#echo "$q<br>-----<br>";
				query_sql($q,$res);
			}
		} else {

			$q  = "UPDATE knowledge SET t_mulai='$t_mulai', t_akhir='$t_akhir', lokasi='$_REQUEST[lokasi]', ";
			$q .= "sharing_status='3', app_req_by='$_SESSION[nik_login]', app_req_at=NOW() WHERE id_know='$_REQUEST[idk]'";
			#echo "1. Approval Request Sharing:<br>$q<br>-----<br>";
			query_sql($q,$res);

			if (strlen($_REQUEST[catatan])>0) {
				$q  = "INSERT INTO sharing_notes (id_know, nik, created, notes) ";
				$q .= "VALUES ('$_REQUEST[idk]', '$_SESSION[nik_login]', NOW(), '$_REQUEST[catatan]')";
				#echo "$q<br>-----<br>";
				query_sql($q,$res);
			}
			// create sharing activity table for contributor/speaker
			$sid_bidang = $_SESSION[id_bidang];
			$tSQL  = "INSERT INTO sharing_activity (id_know,nik,id_bidang,id_confirm,id_inv_status,attend) VALUES ";
			$tSQL .= "('$_REQUEST[idk]','$_REQUEST[niknya]',(SELECT id_bidang FROM user WHERE nik='$_REQUEST[niknya]'),'1','1','1')";
			#echo "2. Create sharing activity table for speaker:<br>$tSQL<br>-----<br>";
			query_sql($tSQL,$res);

			// create sharing activity table for team member
			if (strlen($_REQUEST[member]) > 0) {
				$niks = explode(",",$_REQUEST[member]);
				#echo "3. Create sharing activity table for member of speaker:<br>";
				#echo "<br>\$_REQUEST[member]: $_REQUEST[member]<br>";
				$member = array();
				foreach ($niks as $key => $value) {
					$tSQL  = "INSERT INTO sharing_activity (id_know,nik,id_bidang,id_confirm,id_inv_status,attend) VALUES ";
					$tSQL .= "('$_REQUEST[idk]','$value',(SELECT id_bidang FROM user WHERE nik='$value'),'1','2','1');";
					#echo "3. Create sharing activity table for member of speaker:<br>$tSQL<br>-----<br>";
					query_sql($tSQL,$res);
					$member[] = $value;
				}
				#echo "<br>-----";
				$members = "'".implode("','",$member)."'";
			}

			// get bidang
			$bid = explode(",",$_REQUEST[inv_bid]);
			#echo "$_REQUEST[inv_bid]<br>";
			#echo "<br>5. Create sharing activity table for Invitee (Audience):";
			#echo "<br>\$_REQUEST[inv_bid]: $_REQUEST[inv_bid]";

			#$tSQL = "SELECT COUNT(*) AS jml FROM bidang_test";
			$tSQL = "SELECT COUNT(*) AS jml FROM bidang";
			#echo "$tSQL<br>";
			$result = mysql_query($tSQL);
			$rows = mysql_fetch_object ($result);
			$jml = $rows->jml-1;

			// create sharing activity table for SM RDC if invite RDC
			$nik_sgm = "";
			if (count($bid) == $jml)
			{
				// before...
				#$q="INSERT INTO sharing_activity (id_know,nik,id_inv_status) VALUES ('$_REQUEST[idk]',(SELECT nik FROM user_test WHERE ID_LOKER='100'),'3')";
				// after...
				$q = "SELECT nik FROM user WHERE ID_LOKER='100'";
				query_sql($q,$res);
				$rows = mysql_fetch_object ($res);
				$nik_sgm = $rows->nik;

				$q  = "INSERT INTO sharing_activity (id_know,nik,id_bidang,id_inv_status) ";
				$q .= "VALUES ('$_REQUEST[idk]',(SELECT nik FROM user WHERE ID_LOKER='100'),'100','3')";
				#echo "4. Create sharing activity table for SM RDC<br>$tSQL<br>-----<br>";
				query_sql($q,$res);
			}

			// you have member of speaker
			if (strlen($_REQUEST[member]) > 0)
			{
				$qadd = " AND nik NOT IN ($members)";
			}
			else
			{
				$qadd = "";
			}

			// create sharing activity table for target audience
			foreach ($bid as $key => $value) {
				#$q="SELECT * FROM user_test WHERE id_loker LIKE '".substr($value,0,2)."%' AND active='1' AND nik <> '$_REQUEST[niknya]'".$qadd;
				$q  = "SELECT * FROM user WHERE id_loker LIKE '".substr($value,0,2)."%' ";
				$q .= "AND active='1' AND nik <> '$_REQUEST[niknya]'".$qadd;
				#echo "5. Create sharing activity table for Audience<br>$q<br>-----<br>";
				query_sql($q,$res);
				$result = mysql_query($q);
				while ($row = mysql_fetch_array ($result)) {
					$id_bid = $row[id_bidang];
					$tSQL   = "INSERT INTO sharing_activity (id_know,nik,id_bidang,id_inv_status) ";
					$tSQL  .= "VALUES ('$_REQUEST[idk]','$row[nik]',$id_bid,'3')";
					#echo "$tSQL<br>";
					query_sql($tSQL,$res);
				}
				#echo "-----<br>";
			}

			// get subject & message from subject table
			#$q="SELECT nama,nik,email FROM user WHERE NIK = (SELECT nik FROM knowledge WHERE id_know='$_REQUEST[idk]')";
			$q  = "SELECT a.id_know,a.nik,a.judul,a.lokasi,b.nama,b.email,b.id_bidang ";
			$q .= "FROM knowledge a JOIN user b ON a.nik=b.nik WHERE id_know='$_REQUEST[idk]'"; 
			#echo "//get subject & message from subject table<br>$q<br>-----<br>";
			$id_know= $_REQUEST[idk];
			$result = mysql_query($q);
			$rows   = mysql_fetch_object($result);
			$nik    = $rows->nik;
			$name   = $rows->nama;
			$email  = $rows->email;
			$judul  = $rows->judul;
			$lokasi = $rows->lokasi;
			$idb    = $rows->id_bidang;
			$tgl    = date("d-m-Y",strtotime($t_mulai));
			$jam1   = date("H:i",strtotime($t_mulai));
			$jam2   = date("H:i",strtotime($t_akhir));
			$ids    = 7;

			require_once("sendmail.php");
			sending($ids,$idb,$bid,$external,$nik,$name,$email,$judul,$lokasi,$tgl,$jam1,$jam2,$nik_sgm,$id_know);
		}

		Header("Location: management.php?mn=13");
		break;
?>