<?
/* 
Nama Program: getid_windows.php
Pembuat		: Lutfi
tgl. buat	: Thursday, Jun 19, 2008 9:49:37 AM .281
tgl. revisi	: Thursday, Jul 19, 2009 9:49:37 AM .281
Deskripsi	: Koneksi ke MS SQL Server via Apache on Windows (RDCDB) untuk mengambil data NIK dan
			  koneksi ke MysQL untuk memeriksa profile
Skrip asal	: -
Skrip tujuan: -
*/

/*
(3) Email
(4) id
(0) IDUser
(6) JobTitle
(5) LastLogin
(1) NamaLengkap
(2) NIK
(7) Posisi
(9) UnitKerja
(8) UnitKerjaDesc
*/

// --- Get User Authentication ---
	$dbtype = "ado_mssql";
	$dbhost = "10.14.0.64\rdcdb";
	$dbuser = "ip";
	$dbpass = "telkomrdc";
	$dbname = "member";
	$dbtable= "v_WargaRistiNew";
	include('include/adodb.inc.php'); 

	ADOLoadCode($dbtype);
	$db = &ADONewConnection($dbtype);
	$myDSN="PROVIDER=MSDASQL;DRIVER={SQL Server};"."SERVER=".$dbhost.";DATABASE=".$dbname.";UID=".$dbuser.";PWD=".$dbpass.";"  ;
	$db->Connect($myDSN);
	session_start();
	if (!empty($_REQUEST['id']))
		$sesid = $_REQUEST['id'];
	else
		$sesid = $_SESSION['sid'];
	$sql = "SELECT * FROM $dbtable WHERE id='$sesid'";
	#print "$sql<br>";
	$rs = $db->Execute($sql);

	if (!$rs) {
		print $conn->ErrorMsg();
	} else {
		if (!empty($_REQUEST['id']))
			$_SESSION['sid'] = $_REQUEST['id'];
		$yournik = $rs->fields[2];
		#echo "$yournik<br>";

		$sQuery = "SELECT a.nik, a.nama, a.id_profile, a.id_bidang, b.nm_profile, c.nm_loker FROM user AS a JOIN profile b ON a.id_profile=b.id_profile JOIN loker c ON a.id_loker=c.id_loker WHERE a.nik ='".$yournik."'";
		#echo $sQuery."<br>";
		$result = mysql_query($sQuery) or die('Mysql Err. 1');
		$row = mysql_fetch_object($result);
		
		if (mysql_num_rows($result)>0) {
			$_SESSION['nik_login'] = $row->nik;
			$_SESSION['nik'] = $row->nik;
			$_SESSION['nama'] = $row->nama;
			$_SESSION['email'] = $row->email;
			$_SESSION['id_bidang'] = $row->id_bidang;
			$_SESSION['id_loker'] = $row->id_loker;
			$_SESSION['nm_loker'] = $row->nm_loker;
			$_SESSION['id_profile'] = $row->id_profile;
			$_SESSION['nm_profile'] = $row->nm_profile;
			$_SESSION['nik'] = $row->nik;
			$_SESSION['found'] = 1;
		} else {
			#echo "Data not found!<br>";
			$_SESSION['found'] = 0;
		}
	}
?>