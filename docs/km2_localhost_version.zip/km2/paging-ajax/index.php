<?
/*
-----
file asal  : verlogin.php, mainmenu.php
file tujuan: sharing_schedule.php, sharing_invitation.php, sharing_req_add.php, sharing_req_close.php
			 sharing_req_close_d.php, sharing_req_his.php, sharing_req_edt.php, sharing_schedule.php
-----
*/
session_start();
include ("include/convertdatetime.php");
if (!isset($_SESSION['nik_login']))
{
	Header("Location:login.php");
}
else
{
	$_SESSION['page']=1;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>KMORE - Home</title>
<meta name="Generator" content="EditPlus">
<meta name="Author" content="">
<meta name="Keywords" content="kmore, knowledge management, km on-line report">
<meta name="Description" content="">
<link rel="shortcut icon" href="images/klogo.ico">
<link type="text/css" href="style/master.css" rel="stylesheet">
<link type="text/css" href="style/menu.css" rel="stylesheet">
<link type="text/css" href="style/screen.css" rel="stylesheet" media="screen" />
<link type="text/css" href="style/newsticker.css" rel="stylesheet">
<link type="text/css" href="style/table.css" rel="stylesheet" media="print, projection, screen">

<script type="text/javascript" src="jscript/jquery-1.3.2.min.js"></script>

<!-- Table sorter
<script type="text/javascript" src="jscript/jquery.tablesorter.js"></script>
<script type="text/javascript">
$(function() {		
	$("#myTable").tablesorter();
});	
</script> -->
<!-- /// -->

<!-- AJAX Paging -->
<script type="text/javascript" src="jscript/ajax_req.js"></script>
<link type="text/css" href="style/paging.css" rel="stylesheet">
<!-- /// -->

<!-- Newsticker -->
<script type="text/javascript" src="jscript/jquery.li-scroller.1.0.js"></script>
<script type="text/javascript">
$(function(){
	$("ul#ticker01").liScroll({travelocity: 0.04});
});
</script>
<!-- /// -->

<!-- for thickbox -->
<script type="text/javascript" src="jscript/thickbox.js"></script>
<link type="text/css" href="style/thickbox.css" rel="stylesheet"/>
<!-- end of thickbox -->

</head>

<body>
<div id="maincontainer">
  <?
  include ("header.php");
  ?>

  <div id="contentwrapper"><? include("mainmenu.php"); ?></div>
  <div id="contentwrapper"><? include("newsticker.php"); ?></div>

  <div id="contentwrapper">
	<div id="contentcolumn">
	  <div class="innertube">
	  <script>htmlData('mypaging.php', 'p=1')</script>
	<div id="txtResult"></div>
	<!-- <div style="clear:both"></div> -->

	  <?
	  /*
	  switch ($_REQUEST['mn'])
	  {
		case 1:
			include("sharing_schedule.php");
			break;
		case 2:
			include("sharing_invitation.php");
			break;
		case 31:
			include("sharing_req_add.php");
			break;
		case 32:
			include("sharing_req_close.php");
			break;
		case 321:
			include("sharing_req_close_d.php");
			break;
		case 33:
			include("sharing_req_his.php");
			break;
		case 34:
			include("sharing_req_edt.php");
			break;
		case 99:
			include("findresult.php");
			break;
		default:
			include("sharing_schedule.php");
			$_REQUEST['mn']=1;
			break;
	  }
	  */
	  ?>
	  </div>
	</div>
  </div>

  <div id="leftcolumn">
	<div class="innertube">
	  <ul id="lefttabs">
	  <li><a href="?mn=1" <? if($_REQUEST['mn']==1) echo 'id="current"'; ?>>Sharing Knowledge Schedule</a>
	  <li><a href="?mn=2" <? if($_REQUEST['mn']==2) echo 'id="current"'; ?>>Invitation For Me</a>
	  <li><a href="#" id="slick-toggle">My Sharing Knowledge</a>
		<ul id="lefttabs2">
		  <li><a href="?mn=31" <? if($_REQUEST['mn']==31) echo 'id="current"'; ?>>New Request Sharing</a>
		  <li><a href="?mn=32" <? if($_REQUEST['mn']==32) echo 'id="current"'; ?>>Close Sharing</a>
		  <li><a href="?mn=33" <? if($_REQUEST['mn']==33) echo 'id="current"'; ?>>History</a>
		</ul>
	  <li><a href="#" id="slick-toggle">Report</a>
		<ul id="lefttabs2">
		  <li><a href="#?mn=41" <? if($_REQUEST['mn']==41) echo 'id="current"'; ?>>My Point</a>
		  <li><a href="#?mn=42" <? if($_REQUEST['mn']==42) echo 'id="current"'; ?>>Sharing Point Individu</a>
		  <li><a href="#?mn=43" <? if($_REQUEST['mn']==43) echo 'id="current"'; ?>>Sharing Point Bidang</a>
		  <li><a href="#?mn=44" <? if($_REQUEST['mn']==44) echo 'id="current"'; ?>>Knowledge Map</a>
		</ul>
	  </ul>
	</div>
  </div>

  <? include ("footer.php"); ?>

</div>

</body>
</html>
