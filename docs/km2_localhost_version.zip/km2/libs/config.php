<?php
// http://www.askapache.com/php/phpfreaks-eric-rosebrocks-phpmailer-tutorial.html
// Configuration settings for My Site
 
// Email Settings
#$site['from_name'] = 'Lutfi Achyar'; // from email name
#$site['from_email'] = 'silutfi@google.com'; // from email address
 
// Just in case we need to relay to a different server,
// provide an option to use external mail server.
$site['smtp_mode'] = 'enabled'; // enabled or disabled
$site['smtp_host'] = 'bdgm01.telkom.co.id';
$site['smtp_port'] = '25';
$site['smtp_username'] = 'kmore';
$site['smtp_password'] = 'telkom135';
?>