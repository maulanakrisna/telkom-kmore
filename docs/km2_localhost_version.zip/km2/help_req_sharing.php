<?
$judul = "Request Sharing";
echo "<h3>$judul</h3>";
?>
<br><b>Membuat Request Sharing</b>
<br>Untuk membuat Request Sharing, lakukan langkah2 sbb:
<ul class="report">
<li>Klik menu Sharing > Create Request Sharing
<li>Isi form Request Sharing
<li>untuk memilih tanggal, klik icon kalender yang berada disisi kanan   kolom tanggal
<li>Jika form sudah terisi, tekan tombol submit.
<li>Selanjutnya layar akan menampilkan Request Sharing yang baru dibuat di baris paling atas dari daftar My Sharing Knowledge dengan status Requesting yang artinya request tersebut menunggu persetujuan dari Committee.
</ul>

<br><b>Mengubah Request Sharing</b>

<br>Kita dapat melakukan perubahan terhadap data-data tertentu pada Request Sharing yang telah dibuat selama statusnya masih Requesting (belum mendapat persetujuan dari Committee) dengan mengklik judul Request Sharing-nya.
<br><br>Pada menu edit Request Sharing terdapat tombol Close. Tombol ini untuk menutup Request Sharing 
yang telah kadaluwarsa (status masih Requesting tetapi waktu mulainya telah lewat dari waktu yang berlaku saat itu).

