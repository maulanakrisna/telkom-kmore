<?
http://www.codewalkers.com/c/a/Miscellaneous-Code/PHP-Date-Validation-including-leap-year/
//** ©William Fowler (wmfwlr@cogeco.ca) 
//** January 26/2004, Version 1.0 

//** Returns: Timestamp
//** Get the adjusted timestamp associated with the day, month, and year
//** given. Months and days are indexed starting at one (1). Any date before
//** January 1, 1970 will be converted to year 1970 (due to 'mktime()'
//** limitations).

function GetValidDate($month=1, $day=1, $year=1970)
{
//** provide a default value and convert the day of the month given. Day 
//** cannot be less than 1 or greater than 31.

$day = min(31, max(1, intval($day)));

//** provide a default value and convert the month number given. Month cannot
//** be less than 1 or greater than 12.

$month = min(12, max(1, intval($month)));

//** provide a default value and convert the day of the year number given.

$year = max(1970, intval($year));

//** handle compensating for day runover if the number of days selected is
//** greater than those allowable for the selected month.

switch($month)
{
//** if FEBRUARY the selected day must be corrected and a leap year must be
//** acounted for as well.
//** CHANGED JAN 26/2004 - corrected for leap year error.

case 2 :
if($day > 28)
$day = ($year % 4 == 0 && ($year % 100 != 0 || $year % 400 == 0)) ? 29 : 28;
break;

//** only maximum of thirty days in these months.

case 4 : //** APRIL
case 6 : //** JUNE
case 9 : //** SEPTEMBER
case 11 : //** NOVEMBER

$day = min(30, $day); 
break;
}
//** construct the appropriate date timestamp from the parameters provided.

return mktime(0, 0, 0, $month, $day, $year);
}
?>

<html>
<body>
<form method="post">
<font face="verdana" size="2">

<i>Please choose a date:</i><br>

<select name="month">
<option value="1">January</option>
<option value="2">February</option>
<option value="3">March</option>
<option value="4">April</option>
<option value="5">May</option>
<option value="6">June</option>
<option value="7">July</option>
<option value="8">August</option>
<option value="9">September</option>
<option value="10">October</option>
<option value="11">November</option>
<option value="12">December</option>
</select>

<!-- generate a list of available days in a month, 1 to 31 -->

<select name="day">
<? 
for($index=1; $index <= 31; $index++)
echo "<option value='$index'>$index</option>";
?>
</select>

<!-- generate a list of years to select -->

<select name="year">
<? 
for($index=2000; $index <= 2025; $index++)
echo "<option value='$index'>$index</option>";
?>
</select>

<input type="submit" name="dodisplay" Value=" Validate "><br><br>

<!-- if this form was submitted display the date choosen. -->
<?
if(isset($_REQUEST["dodisplay"]))
{
echo "<i>You Choose:</i> <font color='blue'>", 
date("F d, Y", GetValidDate($_REQUEST["month"],$_REQUEST["day"],$_REQUEST["year"])),
"</font> <i>(", "month=", $_REQUEST["month"], " day=", $_REQUEST["day"],
" year=", $_REQUEST["year"], ")</i>";
}
?>
</font>

</form>
</body>
</html>
