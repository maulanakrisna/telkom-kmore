<?

#header( 'Location: http://www.google.co.id' ) ;

// switch the value of $email to the
// persons email address you are sending
// this to.

$email = "webadmin@localhost";
$subject = "Working PHP v4.0b4 mail script";

$body = "Um, looks good from here.";

$headers = "From: webadmin@localhost\n";
$headers .= "Reply-to: webadmin@localhost\n";
$headers .= "Cc: asep_p@localhost\n";
$headers .= "Bcc: fenti@localhost\n";
$headers .= "Bcc: fridh@localhost\n";
$headers .= "Bcc: yasser@localhost\n";
$headers .= "Content-Type: text/plain; charset=iso-8859-1\n";


mail ($email, $subject, $body, $headers);

echo "schweeeeeet.....its workin'";

?>