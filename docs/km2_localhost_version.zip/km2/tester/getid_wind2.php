<?
/* 
Nama Program: getid_wind2.php
Pembuat		: Lutfi
tgl. buat	: Thursday, Jun 19, 2008 9:49:37 AM .281
tgl. revisi	: Thursday, Jun 19, 2008 9:49:37 AM .281
Deskripsi	: Koneksi ke MS SQL Server Localhost via Apache on Windows (localhost) untuk mengambil data NIK dan
			  koneksi ke MysQL untuk memeriksa apakah ybs terdaftar sbg member Lab IP apa bukan
Skrip asal	: -
Skrip tujuan: -

(3) Email
(4) id
(0) IDUser
(6) JobTitle
(5) LastLogin
(1) NamaLengkap
(2) NIK
(7) Posisi
(9) UnitKerja
(8) UnitKerjaDesc
*/

// --- Get User Authentication ---

	$dbtype = "ado_mssql";
	$dbhost = "MYACER\MSSQL";
	$dbuser = "sa";
	$dbpass = "sqlpassword";
	$dbname = "member";
	$dbtable= "v_WargaRistiNew";
	include('include/adodb.inc.php'); 

	ADOLoadCode($dbtype);
	$db = &ADONewConnection($dbtype);
	$myDSN="PROVIDER=MSDASQL;DRIVER={SQL Server};"."SERVER=".$dbhost.";DATABASE=".$dbname.";UID=".$dbuser.";PWD=".$dbpass.";";
	$db->Connect($myDSN);
	$sql = "SELECT * FROM ".$dbtable." WHERE id='".$_REQUEST[id]."'";
	#print $sql."<br>";
	$rs = $db->Execute($sql);

	if (!$rs) {
		print $conn->ErrorMsg();
	} else {

		session_start();
		#include ('set_session.php');
		$_SESSION['sID'] = $_REQUEST[id];
		include("include/dbcon.php");
		$info = explode('/', $rs->fields[0]);

		# check authentification
		$sQuery = "SELECT a.nik, a.nama, a.id_profile, a.id_bidang, b.nm_profile, c.nm_loker FROM user AS a JOIN profile b ON a.id_profile=b.id_profile JOIN loker c ON a.id_loker=c.id_loker WHERE a.nik ='".$info[1]."' AND active='1'";
		#echo $sQuery."<br>";
		$result = mysql_query($sQuery);
		$row = mysql_fetch_object($result);
		
		if (mysql_num_rows($result)>0) {
			session_start();
			$_SESSION['nik_login'] = $row->nik;
			$_SESSION['nama'] = $row->nama;
			$_SESSION['email'] = $row->email;
			$_SESSION['id_bidang'] = $row->id_bidang;
			$_SESSION['id_loker'] = $row->id_loker;
			$_SESSION['nm_loker'] = $row->nm_loker;
			$_SESSION['id_profile'] = $row->id_profile;
			$_SESSION['nm_profile'] = $row->nm_profile;
			echo "$_SESSION[sID]<br>";
			echo "$_SESSION[nik_login]<br>";
			echo "$_SESSION[nama]<br>";
		}
	}
/*
*/
?>