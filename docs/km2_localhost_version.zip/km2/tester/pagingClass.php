<?php
class Paging
{
	function FindPosition($pageNum)
	{
		// Step 1
		if (empty($pageNum))
		{
			$offset = 0;
			$pageNum = 1;
		}
		else
		{
			$offset = ($pageNum-1) * $recordsPerPage;
		}
		return $offset;
	}

	function totalPages($numrows,$recordsPerPage)
	{
		$maxPage = ceil($numrows/$recordsPerPage);
		return $maxPage;
	}

	function navigation($pageNum,$maxPage)
	{
		$number = "<center>";
		# previous page
		if ($pageNum > 1)
		{
			$previous = $pageNum-1;
			$number = $number . " <a href=\"$file&p=1'\"><< First</a> | <a href=\"$file&p=$previous\">< Previous</a> | ";
		}

		# Google Style...
		# first number
		$number = ($pageNum > 3 ? " ... " : " ");
		for ($i = $pageNum-2; $i <= $pageNum; $i++)
		{ 
			if ($i < 1)
				continue;
			if ($i == $pageNum)
			{
				$number .= "<b>$i</b> ";
			}
			else
			{
				$number .= "<a href=\"$file&p=$i\">$i</a> ";
			}
		}

		# middle number
		# command below is just in case if this page include from other file PHP
		$page = substr($page,strlen($page),-2);
		$number .= " <b>$page</b> ";
		for ($i = $pageNum+1; $i <= ($pageNum+4); $i++)
		{ 
			if ($i > $maxPage)
				break;
			$number .= "<a href=\"$file&p=$i\">$i</a> ";
		}

		# last number
		$number .= ($pageNum+2 < $maxPage ? " ... <a href=\"$file&p=$maxPage\">$maxPage</a> " : " ");

		// next page
		if ($pageNum < $maxPage)
		{
			$next = $pageNum+1;
			$number .= "<a href=\"$file&p=$next\"> Next ></a> | <a href=\"$file&p=$maxPage\"> Last >></a> ";
		}
		$number .= "</center>";
		return $number;
	}
}
?>
