<?
// get knowledge that just inserted
include ("include/dbcon.php");

$q="SELECT a.id_know,a.nik,a.judul,b.nama,b.email,b.id_bidang FROM knowledge a JOIN user_test b ON a.nik=b.nik ORDER BY id_know DESC LIMIT 1"; 
echo "$q<br>---<br>";
$result = mysql_query($q);
$rows = mysql_fetch_object ($result);
$id_know = $rows->id_know;
$name = $rows->nama;
$from = $rows->email;
$judul = $rows->judul;
$idb = 120; //$rows->id_bidang;

include ("send_mail.php");
send_mail_2agent("1",$idb,$name,$from,$judul);
?>