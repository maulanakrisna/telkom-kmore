<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>KMORE - Home</title>
<meta name="Generator" content="EditPlus">
<meta name="Author" content="">
<meta name="Keywords" content="kmore, knowledge management, km on-line report">
<meta name="Description" content="">
<link rel="shortcut icon" href="images/klogo.ico">
<link type="text/css" href="style/master.css" rel="stylesheet">
<link type="text/css" href="style/menu.css" rel="stylesheet">
<link type="text/css" href="style/screen.css" rel="stylesheet" media="screen" />

<script type="text/javascript" src="jscript/jquery-1.3.2.min.js"></script>

<script type="text/javascript" src="jscript/jquery.validate.js" ></script>
<!-- for styling the form -->
<script type="text/javascript" src="jscript/cmxforms.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	$("#commentForm").validate();
});
</script>

</head>

<body>
<div id="maincontainer">
  <?
  include ("header.php");
  include ("include/dbcon.php");
  ?>

  <div id="contentwrapper"><? include("mainmenu.php"); ?></div>
  <div id="contentwrapper"><?# include("newsticker.php"); ?></div>

  <div id="contentwrapper">
	<div id="contentcolumn">
	  <div class="innertube">

	<br>
	<form class="cmxform" id="commentForm" action="save2db.php" method="post">
		<fieldset>
			<h2>New Request Sharing</h2>
			<p>
				<label for="cjudul">Judul/Tema:</label>
				<input type="text" id="cjudul" name="judul" size="100" maxlength="200" class="required"/>
			</p>
			<p>
				<label for="cknowmap">Kategori Knowledge:</label>
				<select name="id_map">
				<?
				   $tSQL = "SELECT * FROM knowledge_map"; 
				   $result = mysql_query($tSQL);
				   $num = mysql_num_rows($result);
				   $cur = 1;
				   while ($num >= $cur) {
					   $listrow = mysql_fetch_array($result);
					   if ($listrow["level"]==2) $spacer="&nbsp;&nbsp;";
					   else if ($listrow["level"]==3) $spacer="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
					   else $spacer="";
						
				?>
				<option value="<?= $listrow["id_map"]; ?>">
				<? echo $spacer.$listrow["id_map"]."&nbsp;-&nbsp;".$listrow["nm_map"]; ?>
				</option>
				<?
					   $cur++;
				   }
				?>
				</select>
			</p>
			<p>
				<label for="cjenis">Jenis Materi:</label>
				<input type="text" id="cjenis" name="jenis" size="50"/>&nbsp;&nbsp;e.g: Standard, Kajian, Best Practice, etc.
			</p>
			<p><!-- Otomatis -->
				<label for="csubmitter">Pengirim:</label>
				<input type="text" id="csubmitter" name="submitter" size="50" value="<?= $_SESSION[nik]." - ".$_SESSION[nama]; ?>" readonly/>
			</p>
			<p><!-- Otomatis -->
				<label for="csubmitter">Pengirim:</label>
				<input type="text" id="csubmitter" name="submitter" size="50" value="<?= $_SESSION[nik]." - ".$_SESSION[nama]; ?>" readonly/>
			</p>
			<p><!-- Otomatis -->
				<label for="cname">Pembicara:</label>
				<select name="nik" onChange="get_loker(this.value)">
				<?
				   $tSQL = "SELECT a.*, b.nm_loker FROM user a JOIN loker b ON a.id_loker=b.id_loker WHERE a.active='1' ORDER BY nama"; 
				   $result = mysql_query($tSQL);
				   $num = mysql_num_rows($result);
				   $cur = 1;
				   while ($num >= $cur){
					   $listrow = mysql_fetch_array($result);
				?>
				<option value="<?= $listrow["nik"]."-".$listrow["id_loker"]; ?>" <? if ($listrow["nik"]==$_SESSION['nik']) echo "selected"; ?>><? echo $listrow["nik"]." - ".$listrow["nama"]; ?></option>
				<?
					   $cur++;
				   }
				?>
				</select>
			</p>
			<p>
				<label for="cname">Pembicara Lainnya</label><br>
				<label for="cname">Pembicara 2:</label>
				<select name="nik2" onChange="get_loker(this.value)">
				<option value="">- Pilih -</option>
				<?
				   $tSQL = "SELECT a.*, b.nm_loker FROM user a JOIN loker b ON a.id_loker=b.id_loker WHERE a.active='1' AND a.nik <> $_SESSION[nik_login] ORDER BY nama"; 
				   $result = mysql_query($tSQL);
				   $num = mysql_num_rows($result);
				   $cur = 1;
				   while ($num >= $cur){
					   $listrow = mysql_fetch_array($result);
				?>
				<option value="<?= $listrow["nik"]; ?>"><? echo $listrow["nik"]." - ".$listrow["nama"]; ?></option>
				<?
					   $cur++;
				   }
				?>
				</select><br>
				<label for="cname">Pembicara 3:</label>
				<select name="nik3" onChange="get_loker(this.value)">
				<option value="">- Pilih -</option>
				<?
				   $tSQL = "SELECT a.*, b.nm_loker FROM user a JOIN loker b ON a.id_loker=b.id_loker WHERE a.active='1' AND a.nik <> $_SESSION[nik_login] ORDER BY nama"; 
				   $result = mysql_query($tSQL);
				   $num = mysql_num_rows($result);
				   $cur = 1;
				   while ($num >= $cur){
					   $listrow = mysql_fetch_array($result);
				?>
				<option value="<?= $listrow["nik"]; ?>"><? echo $listrow["nik"]." - ".$listrow["nama"]; ?></option>
				<?
					   $cur++;
				   }
				?>
				</select>
				</select><br>
				<label for="cname">Pembicara 4:</label>
				<select name="nik4" onChange="get_loker(this.value)">
				<option value="">- Pilih -</option>
				<?
				   $tSQL = "SELECT a.*, b.nm_loker FROM user a JOIN loker b ON a.id_loker=b.id_loker WHERE a.active='1' AND a.nik <> $_SESSION[nik_login] ORDER BY nama"; 
				   $result = mysql_query($tSQL);
				   $num = mysql_num_rows($result);
				   $cur = 1;
				   while ($num >= $cur){
					   $listrow = mysql_fetch_array($result);
				?>
				<option value="<?= $listrow["nik"]; ?>"><? echo $listrow["nik"]." - ".$listrow["nama"]; ?></option>
				<?
					   $cur++;
				   }
				?>
				</select>
			</p>
			<p>
				<label for="ctanggal">Tanggal:</label>
				<select name="tanggal" onChange="getState(this.value)">
				<option value="01" <? if (date("d")== "01") echo "selected"; ?>>1</option>
				<option value="02" <? if (date("d")== "02") echo "selected"; ?>>2</option>
				<option value="03" <? if (date("d")== "03") echo "selected"; ?>>3</option>
				<option value="04" <? if (date("d")== "04") echo "selected"; ?>>4</option>
				<option value="05" <? if (date("d")== "05") echo "selected"; ?>>5</option>
				<option value="06" <? if (date("d")== "06") echo "selected"; ?>>6</option>
				<option value="07" <? if (date("d")== "07") echo "selected"; ?>>7</option>
				<option value="08" <? if (date("d")== "08") echo "selected"; ?>>8</option>
				<option value="09" <? if (date("d")== "09") echo "selected"; ?>>9</option>
				<option value="10" <? if (date("d")== "10") echo "selected"; ?>>10</option>
				<option value="11" <? if (date("d")== "11") echo "selected"; ?>>11</option>
				<option value="12" <? if (date("d")== "12") echo "selected"; ?>>12</option>
				<option value="13" <? if (date("d")== "13") echo "selected"; ?>>13</option>
				<option value="14" <? if (date("d")== "14") echo "selected"; ?>>14</option>
				<option value="15" <? if (date("d")== "15") echo "selected"; ?>>15</option>
				<option value="16" <? if (date("d")== "16") echo "selected"; ?>>16</option>
				<option value="17" <? if (date("d")== "17") echo "selected"; ?>>17</option>
				<option value="18" <? if (date("d")== "18") echo "selected"; ?>>18</option>
				<option value="19" <? if (date("d")== "19") echo "selected"; ?>>19</option>
				<option value="20" <? if (date("d")== "20") echo "selected"; ?>>20</option>
				<option value="21" <? if (date("d")== "21") echo "selected"; ?>>21</option>
				<option value="22" <? if (date("d")== "22") echo "selected"; ?>>22</option>
				<option value="23" <? if (date("d")== "23") echo "selected"; ?>>23</option>
				<option value="24" <? if (date("d")== "24") echo "selected"; ?>>24</option>
				<option value="25" <? if (date("d")== "25") echo "selected"; ?>>25</option>
				<option value="26" <? if (date("d")== "26") echo "selected"; ?>>26</option>
				<option value="27" <? if (date("d")== "27") echo "selected"; ?>>27</option>
				<option value="28" <? if (date("d")== "28") echo "selected"; ?>>28</option>
				<option value="29" <? if (date("d")== "29") echo "selected"; ?>>29</option>
				<option value="20" <? if (date("d")== "30") echo "selected"; ?>>30</option>
				<option value="31" <? if (date("d")== "31") echo "selected"; ?>>31</option>
				</select>
				<select name="bulan" onChange="getState(this.value)">
				<option value="01" <? if (date("m")== "01") echo "selected"; ?>>Januari</option>
				<option value="02" <? if (date("m")== "02") echo "selected"; ?>>Februari</option>
				<option value="03" <? if (date("m")== "03") echo "selected"; ?>>Maret</option>
				<option value="04" <? if (date("m")== "04") echo "selected"; ?>>April</option>
				<option value="05" <? if (date("m")== "05") echo "selected"; ?>>Mei</option>
				<option value="06" <? if (date("m")== "06") echo "selected"; ?>>Juni</option>
				<option value="07" <? if (date("m")== "07") echo "selected"; ?>>Juli</option>
				<option value="08" <? if (date("m")== "08") echo "selected"; ?>>Agustus</option>
				<option value="09" <? if (date("m")== "09") echo "selected"; ?>>September</option>
				<option value="10" <? if (date("m")== "10") echo "selected"; ?>>Oktober</option>
				<option value="11" <? if (date("m")== "11") echo "selected"; ?>>Nopember</option>
				<option value="12" <? if (date("m")== "12") echo "selected"; ?>>Desember</option>
				</select>
				<select name="tahun" onChange="getState(this.value)">
				<option value="2007" <? if (date("Y")== "2007") echo "selected"; ?>>2007</option>
				<option value="2008" <? if (date("Y")== "2008") echo "selected"; ?>>2008</option>
				<option value="2009" <? if (date("Y")== "2009") echo "selected"; ?>>2009</option>
				<option value="2010" <? if (date("Y")== "2010") echo "selected"; ?>>2010</option>
				<option value="2011" <? if (date("Y")== "2011") echo "selected"; ?>>2011</option>
				<option value="2012" <? if (date("Y")== "2012") echo "selected"; ?>>2012</option>
				<option value="2013" <? if (date("Y")== "2013") echo "selected"; ?>>2013</option>
				<option value="2014" <? if (date("Y")== "2014") echo "selected"; ?>>2014</option>
				<option value="2015" <? if (date("Y")== "2015") echo "selected"; ?>>2015</option>
				<option value="2016" <? if (date("Y")== "2016") echo "selected"; ?>>2016</option>
				<option value="2017" <? if (date("Y")== "2017") echo "selected"; ?>>2017</option>
				<option value="2018" <? if (date("Y")== "2018") echo "selected"; ?>>2018</option>
				<option value="2019" <? if (date("Y")== "2019") echo "selected"; ?>>2019</option>
				<option value="2020" <? if (date("Y")== "2020") echo "selected"; ?>>2020</option>
				</select>
			</p>
			<p>
				<label for="cjmulai">Jam Mulai:</label>
				<select name="jmulai" onChange="getState(this.value)">
				<option value="08">08</option>
				<option value="09">09</option>
				<option value="10">10</option>
				<option value="11">11</option>
				<option value="12">12</option>
				<option value="13">13</option>
				<option value="14">14</option>
				<option value="15">15</option>
				<option value="16">16</option>
				<option value="17">17</option>
				<option value="18">18</option>
				</select>&nbsp;:
				<select name="mmulai" onChange="getState(this.value)">
				<option value="00">00</option>
				<option value="30">30</option>
				</select>
			</p>
			<p>
				<label for="cjusai">Jam Selesai:</label>
				<select name="jusai" onChange="getState(this.value)">
				<option value="09">09</option>
				<option value="10">10</option>
				<option value="11">11</option>
				<option value="12">12</option>
				<option value="13">13</option>
				<option value="14">14</option>
				<option value="15">15</option>
				<option value="16">16</option>
				<option value="17">17</option>
				<option value="18">18</option>
				<option value="19">19</option>
				</select>&nbsp;:
				<select name="musai" onChange="getState(this.value)">
				<option value="00">00</option>
				<option value="30">30</option>
				</select>&nbsp;&nbsp;
			</p>
			<p>
				<label for="cruang">Lokasi Ruangan:</label>
				<input type="text" id="clokasi" name="lokasi" size="100" class="required"/>
			</p>
			<div id="lokerdiv"><p>
				<label for="cunitkerja">Unit Kerja:</label>
				<input type="text" id="cunitkerja" name="unitkerja" size="100" value="<?=$_SESSION['nm_loker']?>" readonly/>
			</p></div>
			<p>
				<?
				   $tSQL = "SELECT * FROM loker WHERE id_top='100'"; 
				   $result = mysql_query($tSQL);
				   $num = mysql_num_rows($result);
				   $cur = 1;
				   $for_invite = array();
				   while ($num >= $cur){
					   $listrow = mysql_fetch_array($result);
					   $for_invite[] = $listrow['id_loker'];
				?>
				<? if ($cur == 1) { ?>
				<label for="ctaudien">Target Audience:</label>
				<? } else { ?>
				<label>&nbsp;</label><? } ?>
				<input type="checkbox" id="cbidang[]" name="bidang[]" value="<?= $listrow['id_loker']; ?>" <? if ($listrow['id_loker']==$_SESSION['id_bidang']) echo "checked"; ?>/>&nbsp;<? echo $listrow['nm_loker']; ?><br>
				<?
					   $cur++;
				   }
				?>
			</p>
			<p>
				<label for="cabstraksi">Abstraksi:</label>
				<textarea id="cabstraksi" name="abstraksi" rows="5" cols="97" class="required"></textarea>
			</p>
			<p>
				<label for="charapan">Harapan:</label>
				<textarea id="charapan" name="harapan" rows="5" cols="97"></textarea>
			</p>
			<p>
				<label for="creferen">Referensi:</label>
				<textarea id="creferensi" name="referensi" rows="5" cols="97"></textarea>
			</p>
			<p>
				<label>&nbsp;</label><input type="submit" class="submit" value="Submit"/>
				<input type="hidden" name="sw" value="11"/>
			</p>
		</fieldset>
	</form>
