<?
echo "Hello<br>";
echo "Click <a href='2.php'>here</a>";

?>