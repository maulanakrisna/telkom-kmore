<?
include("include/dbcon.php");
$q="INSERT INTO testdong (created) VALUES (NOW())";
query_sql($q,$res);
?>