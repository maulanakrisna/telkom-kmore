<?
		include("include/dbcon.php");
		// get knowledge that just inserted
		$q="SELECT a.id_know,a.nik,b.nama,b.email,b.id_bidang FROM knowledge a JOIN user b ON a.nik=b.nik ORDER BY id_know DESC LIMIT 1"; 
		#echo "<br>==>&nbsp;$q<br>";
		$result = mysql_query($q);
		$rows = mysql_fetch_object ($result);
		$id_know = $rows->id_know;
		$nik = $rows->nik;
		$name = $rows->nama;
		$email = $rows->email;
		$judul = $rows->judul;
		$idb = $rows->id_bidang;
		$ids = 1;

		include ("sendmail.php");
?>