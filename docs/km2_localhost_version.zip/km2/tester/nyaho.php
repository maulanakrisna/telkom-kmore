<?
// test array, using implode()
$member = array("satu","dua","tiga","empat");
foreach ($member AS $key => $value) {
	echo "$key - $value<br>";
}
$strmember = "'".implode("','",$member)."'";
echo $strmember;
?>