<?
require_once ("include/dbcon.php");
#echo "$query<br>";

$file = 'index.php?mn=1';

include("pagingClass.php");
$pg = new Paging;

$recordsPerPage = 15;

$offset = $pg->findPosition($recordsPerPage);

$query = "SELECT a.*, b.nm_loker, c.nm_profile FROM user a JOIN loker b ON a.id_loker=b.id_loker JOIN profile c ON a.id_profile=c.id_profile";
$result = mysql_query($query." LIMIT $offset, $recordsPerPage") or die('Mysql Err. 1');

# print table header
echo "<table class='spacer' width='750' border='0'><tr><td><h3>Daftar User</h3></td><td align='right' style='padding-right:2px'>Page: $pageNum</td></tr></table>";
echo "<table id='myTable' class='tablesorter' border='0' cellpadding='0' cellspacing='1'>";
echo "<thead><tr><th>No.</th><th>NIK</th><th>Nama</th><th>Loker</th><th>Email</th><th>Status</th></tr></thead>";
echo "<tbody>";

# print table rows
$no =  $offset+1;
while ($row = mysql_fetch_array($result))
{
?>
	<tr valign="top">
	<td align="right"><?= $no; ?>.</td>
	<td><a href='user_detail.php?id=<?= $row[nik]; ?>' title="User Detail" class="thickbox"><?= $row[nik]; ?></a></td>
	<td><?= $row[nama]; ?></td>
	<td><?= $row[nm_loker]; ?></td>
	<td><?= $row[email]; ?></td>
	<td><? if($row[active]==0) echo "Not Active"; else echo "Active"; ?></td>
	</tr>
<?
	$no++;
}
echo "</tbody>";
echo "</table><p>";

$result = mysql_query($query) or die('Mysql Err. 2');
$numrows = mysql_num_rows($result);

$maxPage = $pg->totalPages($numrows,$recordsPerPage);

$pageLink = $pg->navigation($_GET[p],$maxPage);
echo $pageLink;
?>