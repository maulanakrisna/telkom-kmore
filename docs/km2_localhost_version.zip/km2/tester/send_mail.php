<?
function send_mail_2agent($ids,$idb,$name,$from,$judul)
{
		// get subject & message from subject table
		$q="SELECT * FROM subject WHERE id_subject='$ids'";
		echo "$q<br>";
		$result = mysql_query($q);
		$rows = mysql_fetch_object ($result);
		$subject = $rows->nm_subject;
		$message = $name." (NIK:".$nik.") ".$rows->message." dengan judul \"".$judul."\".<br>";
		$message .= $rows->message2;

		// Grab our config settings
		require_once('libs/config.php');
		 
		// Grab the FreakMailer class
		require_once('libs/MailClass.inc');
		 
		// instantiate the class
		$mailer = new FreakMailer();

		// Set sender
		$mailer->FromName = $name;
		$mailer->From = $from;

		// Set the subject
		$mailer->Subject = $subject;
		 
		// Body
		$mailer->Body = $message;
		$mailer->isHTML(true);

		// send email to agent/committee
		$q="SELECT nik,nama,email FROM user_test WHERE id_bidang='$idb'";
		echo "$q<br>";
		$result = mysql_query($q);

		// Testing
		echo "Subject: $subject<br>";
		echo "From: $name &lt;$from&gt;<br>";
		$x = 1;
		while ($rows = mysql_fetch_object ($result))
		{
			$rcp_name = $rows->nama;
			$rcp_email = $rows->email;
			if ($x==1)
			{
			// Add an address to send to.
				$mailer->AddAddress($rcp_email, $rcp_name);
				echo "To: $rcp_name &lt;$rcp_email&gt;<br>";
			}
			else
			{
			// Add CC address.
				$mailer->AddCC($rcp_email, $rcp_name);
				echo "CC: $rcp_name &lt;".$rcp_email."&gt;<br>";
			}
			$x++;
		}
		echo "Message:<br>$message<br>";

		if(!$mailer->Send())
		{
			echo 'There was a problem sending this mail!';
		}
		else
		{
			echo 'Mail sent!';
		}

		$mailer->ClearAddresses();
		$mailer->ClearAttachments();
	}
return
?>