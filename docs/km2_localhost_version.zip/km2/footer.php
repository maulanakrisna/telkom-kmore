  <div id="contentwrapper">
  <div id="footer">PT. TELKOM INDONESIA R&D CENTER &copy; 2009</div>
  </div>