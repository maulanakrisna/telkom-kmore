<?
session_start();
/*
-----
file asal  : sharing_schedule.php, sharing_req_his.php, newsticker.php
file tujuan: save2db.php?sw=16
-----
*/
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>KMORE - View Sharing Knowledge Feedback</title>
<meta name="Generator" content="EditPlus">
<meta name="Author" content="">
<meta name="Keywords" content="">
<meta name="Description" content="">
<link type="text/css" href="style/master.css" rel="stylesheet"/>
<style type="text/css">
table tr td {
	vertical-align: top;
	border: 0px solid #408080;
}
td {
	padding: 0 3;
}
h2 {
	padding: 0 auto;
	text-align: center;
}
.mycolor {
	background: #A9D3BB;
}
.mycolor2 {
	background: #F2F2F2;
a.thick:link { text-decoration: none; color: #0000FF; }
a.thick:visited { text-decoration: none; color: #0000FF; }
a.thick:hover { text-decoration: underline; color: #FF0000; }
a.confirm:link { text-decoration: none; color: #0000FF; }
}
</style>
</head>

<?
include("include/dbcon.php");
#include ("getid_linux.php"); //dits server to db dits server
#include ("getid_wind.php"); //localhost to db dits server
include ("getid_wind_tester.php"); //localhost to db dits server
// cek daftar hadir
$q = "SELECT a.id_know, a.comment, b.judul, c.nama, c.nik AS contributor FROM feedback a JOIN knowledge b ON a.id_know=b.id_know JOIN user c ON b.nik=c.nik WHERE a.id_know = '$_REQUEST[idk]' AND a.nik = '$_SESSION[nik_login]'";
#echo "$q<br>";
$result = mysql_query($q);
$row = mysql_fetch_array($result);
?>

<body>
<br>
<?#= "\$_SESSION[nik_login]: $_SESSION[nik_login]<br>"; ?>
<table width="600" cellpadding='5' cellspacing='1' align="center">
	<tr>
		<td class="mycolor">Title/Theme:</td>
		<td class="mycolor2" width="75%"><?= $row["judul"]; ?></td>
	</tr>
	<tr>
		<td class="mycolor">Contributor:</td>
		<td class="mycolor2"><?= $row['nama']."&nbsp(".$row['contributor'].")"; ?></td>
	</tr>
	<tr>
		<td class="mycolor">Comment:</td>
		<td class="mycolor2"><textarea name="komen" rows="5" cols="97" readonly><?= $row['comment']; ?></textarea></td>
	</tr>
</table>

<center>
<br>
</td>
<br>
</center>
</body>
</html>
