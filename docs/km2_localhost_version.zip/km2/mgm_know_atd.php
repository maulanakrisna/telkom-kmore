<?php

// Step 1
$judul = "Add Sharing Knowledge Attendance Sheet";
require_once ("include/dbcon.php");

// Step 2
#$query = "SELECT a.*,b.nama,c.nm_loker,d.nm_confirm FROM sharing_activity a JOIN user b ON a.nik=b.nik JOIN loker c ON b.id_bidang=c.id_loker JOIN confirm d ON a.id_confirm=d.id_confirm WHERE id_know='$_REQUEST[idk]' AND a.id_confirm BETWEEN '1' AND '2' ORDER BY a.id_inv_status,c.id_loker,b.nik";
$query = "SELECT * FROM knowledge WHERE id_know = $_REQUEST[idk]";
#echo "$query<br>";
query_sql($query,$result);
$rows    = mysql_fetch_object ($result);
$judul   = $rows->judul;
$contrib = $rows->nik;
$inv_bid = $rows->inv_bidang;

$query = "SELECT a.nik,a.nama,b.nm_loker FROM user a JOIN loker b ON a.id_loker=b.id_loker WHERE id_bidang IN ('$inv_bid')";
#echo "$query<br>";
query_sql($query,$result);

#echo "<table class='spacer' width='750' border='0'><tr><td><h3>$judul</h3></td><td align='right' style='padding-right:2px'>Page: $pageNum</td></tr>";
echo "<h3>$judul</h3>";

# print table header
echo "<table border='0' cellpadding='0' cellspacing='1'>";
echo "<tr>";
echo "</tr>";
echo "</table>";
echo "<form action='save2db.php' method='post'>";
echo "<table id='myTable' class='tablesorter' border='0' cellpadding='0' cellspacing='1'>";
echo "<thead><tr><th>No.</th><th>NIK</th><th>Nama</th><th>Loker</th><th>Attend</th></tr></thead>";
echo "<tbody>";

# print table rows
$no =  $offset+1;
while ($row = mysql_fetch_array($result))
{
?>
	<tr valign="top">
		<td align="right"><?= $no; ?>.</td>
		<td><?= $row["nik"]; ?></td>
		<td><?= $row["nama"]; ?></td>
		<td><?= $row["nm_loker"]; ?></td>
		<td align="center"><input type="checkbox" id="cattend[]" name="attend[]" value="<?= $row["nik"]; ?>"></td>
	</tr>
<?
	$no++;
}
echo "</tbody>";
echo "<input type='hidden' name='idk' value='$_REQUEST[idk]'>";
echo "<input type='hidden' name='sw' value='512'>";
echo "<tr align='center'><td colspan='6'><input type='submit' name='submit' value='Submit'></td></tr>";
echo "</form>";
echo "</table>";
?>
