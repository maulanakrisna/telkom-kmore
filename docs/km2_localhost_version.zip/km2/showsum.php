<?
include ("include/dbcon.php");
$sQuery= "SELECT SUM(poin) AS yourpoin FROM sharing_activity WHERE id_confirm='1'";
echo "$q";
query_sql($sQuery,$result);
$rows = mysql_fetch_object ($result);
echo $rows->yourpoin;
?>