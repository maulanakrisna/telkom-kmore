<?
// crontab_checktaskapp.php
// created: 2009/11/03 9:30 AM
// Status: pending!
session_start();

// http://www.askapache.com/php/phpfreaks-eric-rosebrocks-phpmailer-tutorial.html
include('include/dbcon.php');

// Grab our config settings
include('libs/config.php');
 
// Grab the FreakMailer class
include('libs/MailClass.inc');

// Get the subject from subject table
$q = "SELECT nm_subject,message,message2 FROM subject2 WHERE id_subject=5";
#echo "$q<br>---<br>";
$result = mysql_query($q);
$rows = mysql_fetch_object ($result);
$subject = $rows->nm_subject;
$msg1 = $rows->message;
$msg2 = $rows->message2;

// Check Close Sharing Task
$sender_email = "kmore@ristinet.com";
$sender_name  = "KMORE";
$q  = "SELECT a.id_know,a.judul,a.t_akhir,a.nik,a.sharing_status,b.nama,b.email FROM knowledge a JOIN user b ON a.nik=b.nik ";
$q .= "WHERE sharing_status ='5'";
echo "$q<br><br>";
$res  = mysql_query($q);
#$r = mysql_fetch_object ($res);
while ($r = mysql_fetch_object ($res))
{
	// create random id for id notification
	$id_not = md5(uniqid(rand(), true));

	// create notification close task report => send notification to commitee
	$q = "INSERT INTO notification (id_not,id_know,created,subject) VALUES ('$id_not','".$r->id_know."',NOW(),'".substr($subject,8,strlen($subject))."')";
	#echo "<br>$q<br>";
	query_sql($q,$result);

	/*
	// create notification for nik
	$q = "INSERT INTO notification_4nik (id_not,id_know,nik) VALUES ('$id_not','".$r->id_know."','".$r->nik."')";
	#echo "<br>$q<br><br>";
	query_sql($q,$result);
	*/

	// instantiate the class
	$mailer = new FreakMailer();

	// Set sender
	$mailer->FromName = $sender_email; //'Your Name';
	$mailer->From = $sender_name; //'You@yourdomain.com';

	// Set the subject
	$mailer->Subject = $subject;
	 
	// Body
	$message  = "$msg1:<br>";
	$message .= "\"".$r->judul."\" untuk segera ditutup.<br>";
	$message .= "$msg2<br>";
	$mailer->Body = $message;

	$r_mail = $r->email; #"lutfi_san@yahoo.com"
	$r_name = $r->nama; #"Lutfi Achyar"
	$mailer->AddAddress($r_mail, $r_name); // recipient's email & name
	$mailer->isHTML(true);

	if ($mailer->Send())
	{
		/*
		// Tester
		echo "Subject: $subject - id_know: $r->id_know - sharing_status: $r->sharing_status<br>";
		echo "From: $sender_email &lt;$sender_name&gt;<br>";
		echo "To: ".$r_name." &lt;".$r_mail."&gt;<br>";	
		echo "Message:<br>$message<br><br>";
		*/
		echo "E-mail notifikasi untuk $r_mail &lt;$r_name&gt; <b>terkirim</b><br>";
	}
	else
	{
		echo "E-mail notifikasi untuk $r_mail &lt;$r_name&gt; <b>tidak terkirim!</b><br>";
	}
	$mailer->ClearAddresses();
	$mailer->ClearAttachments();
}
?>