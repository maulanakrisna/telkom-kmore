  <div id="topsection">  </div>
	<?
	switch ($_SESSION['page']) {
		case "1" :
			$filename = "index.php";
			break;
		case "2" :
			$filename = "mgm_sharing.php";
			break;
		case "3" :
			$filename = "admin.php";
			break;
		case "4" :
			$filename = "sitemap.php";
			break;
		case "5" :
			$filename = "help.php";
			break;
  }
  ?>
  <!--
  <div class="blocktext">
  <form name="find" method="get" action="index.php">
  <input type="text" name="keyword" value="<?= $_GET["keyword"]; ?>"><input type="submit" value="Find">
  <input type="hidden" name="mn" value="99">
  </form>
  </div>
  -->