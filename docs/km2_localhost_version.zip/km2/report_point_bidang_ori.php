<?php

// Step 1
$judul = "Sharing Point Bidang";
require_once ("include/dbcon.php");

// Step 2
$query  = "SELECT c.id_loker, c.nm_loker, SUM(a.poin) AS nilai FROM sharing_activity a ";
$query .= "JOIN user b ON a.nik=b.nik JOIN loker c ON b.id_bidang=c.id_loker WHERE id_bidang<>100 ";
$query .= "GROUP BY c.nm_loker ORDER BY nilai DESC, id_inv_status";

#echo "$query<br>";
$result = mysql_query($query) or die('Mysql Err. 1');
$num = mysql_num_rows($result);

echo "<table class='spacer' border='0'><tr><td colspan='2'><h3>$judul</h3></td></tr>";
echo "</td></tr>";
?>
<form name="chooseDateForm" id="chooseDateForm" action="#">
<table>
	<tr><td><label for="start-date">Periode:</label></td>
		<td><input type="text" name="start-date" value="01-01-<?= date("Y"); ?>" size="10" maxlength="10"/></td>
		<td><label for="end-date">&nbsp;s/d:&nbsp;</label></td>
		<td><input type="text" name="end-date" value="<?= date("d-m-Y"); ?>" size="10" maxlength="10"/></td>
		<td><input type="submit" name="submit" value="&nbsp;Go&nbsp;"/></td>
		</tr>
</table>
</form>

<?
# print table header
echo "</table><center>";
echo "<table id='myTable' class='tablesorter' border='0' cellpadding='0' cellspacing='1'>";
echo "<thead><tr><th>No.</th><th>Bidang</th><th>Nilai</th></tr></thead>";
echo "<tbody>";

if ($num <> 0)
{
	# print table rows
	$no =  $offset+1;
	while ($row = mysql_fetch_array($result))
	{
?>
	<tr valign="top">
		<td align="right" width="10px"><?= $no; ?>.</td>
		<td><a href="sharing_point_bidang_d.php?id=<?= $row["id_loker"]?>&height=500&width=810" title="Sharing Point Bidang Detail" class="thickbox"><?= $row["nm_loker"]; ?></a></td>
		<td><?= $row["nilai"]; ?></td>
	</tr>
<?
		$no++;
	}
	echo "</tbody>";
	echo "</table><p>";
	include ("default.php");

}
else
{		
	echo "<tr><td colspan='9' align='center'>Sorry, no individual sharing point report at this time!</td></tr>";
	echo "</tbody>";
	echo "</table><p>";
}
echo "</center>";
?>
