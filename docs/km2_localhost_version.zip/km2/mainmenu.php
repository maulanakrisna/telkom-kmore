	<div id="nav">&nbsp;&nbsp;&nbsp;
	<ul id="minitabs"> 
	<?
	$linksession = "id=".$_SESSION['sid'];
	# Home
	echo '<li><a href="index.php?'.$linksession.'"';
	if ($_SESSION['page']==1) echo ' id="current"';
	echo '>Home</a></li>';

	# Sharing
	echo '<li><a href="sharing.php?'.$linksession.'"';
	if ($_SESSION['page']==2) echo ' id="current"';
	echo '>Sharing</a></li>';

	# Report
	echo '<li><a href="report.php?'.$linksession.'"';
	if ($_SESSION['page']==3) echo ' id="current"';
	echo '>Report</a></li>';

	if ($_SESSION['id_profile']<3)
	{
	# Management
		echo '<li><a href="management.php?'.$linksession.'"';
		if ($_SESSION['page']==4) echo ' id="current"';
		echo '>Management</a></li>';
	}
	if ($_SESSION['id_profile']==1)
	{
	# Admin
		echo '<li><a href="admin.php?'.$linksession.'"';
		if ($_SESSION['page']==5) echo ' id="current"';
		echo '>Admin</a></li>';
	}

	# Sitemap
	echo '<li><a href="sitemap.php?'.$linksession.'"';
	if ($_SESSION['page']==6) echo ' id="current"';
	echo '>Sitemap</a></li>';

	# Help
	echo '<li><a href="help.php?'.$linksession.'"';
	if ($_SESSION['page']==7) echo ' id="current"';
	echo '>Help</a></li>';

	# Logout
	#echo '<li><a href="logout.php">Logout</a></li>';
	?>
	</ul> 
	</div>

	<div id="show"><b><?= $_SESSION['nama']; ?>&nbsp;-&nbsp;<?= $_SESSION['nm_profile']; ?></b>
	</div>

	<!-- <div id="line"></div> -->
