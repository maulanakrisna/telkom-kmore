<?
/* 
Nama Program: upload.php
Pembuat		: Lutfi
tgl. buat	: Saturday, July 12, 2008 11:41:51 AM .093
tgl. revisi	: Saturday, July 12, 2008 11:41:51 AM .093
Deskripsi	: path lokasi file upload
Skrip asal	: product_save.php, service_save.php
Skrip tujuan: -
*/
#$uploadDir = '/opt/lampp/htdocs/lip3/temp/';
$uploadDir = '/xampp/htdocs/km2/upload/';
?>