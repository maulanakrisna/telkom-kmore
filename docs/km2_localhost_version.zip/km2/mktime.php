<?php
$tomorrow = mktime(date("H")-1, 0, 0, date("m"), date("d")+1, date("y"));
echo "Tomorrow is ".date("m/d/y H:i:s", $tomorrow); 
?>