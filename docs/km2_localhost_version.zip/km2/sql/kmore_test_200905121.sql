-- phpMyAdmin SQL Dump
-- version 2.8.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: May 12, 2009 at 11:47 AM
-- Server version: 5.0.22
-- PHP Version: 5.1.4

DROP DATABASE IF EXISTS `kmore`;

CREATE DATABASE `kmore`;

USE `kmore`;

-- 
-- Database: `kmore`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `bidang`
-- 

CREATE TABLE `bidang` (
  `id_bidang` smallint(3) NOT NULL,
  `nm_bidang` varchar(100) default NULL,
  `singkatan` varchar(4) default NULL,
  `email` varchar(100) default NULL,
  PRIMARY KEY  (`id_bidang`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `bidang`
-- 

INSERT INTO `bidang` VALUES (100, 'TELKOM RDC', 'RDC', 'rdc_sgm@telkom.co.id');
INSERT INTO `bidang` VALUES (110, 'General Support', 'GS', 'rdc_gs@telkom.co.id');
INSERT INTO `bidang` VALUES (120, 'Bidang Planning & Controlling', 'RDI', 'rdc_rdi@telkom.co.id');
INSERT INTO `bidang` VALUES (130, 'Bidang R&D of Infrastructure', 'PNC', 'rdc_pnc@telkom.co.id');
INSERT INTO `bidang` VALUES (140, 'Bidang R&D of Network Management', 'RDNM', 'rdc_rdnm@telkom.co.id');
INSERT INTO `bidang` VALUES (150, 'Bidang R&D of Service & Product', 'RDSP', 'rdc_rdsp@telkom.co.id');
INSERT INTO `bidang` VALUES (160, 'Bidang Research of Business', 'ROB', 'rdc_rob@telkom.co.id');

-- --------------------------------------------------------

-- 
-- Table structure for table `closing_notes`
-- 

CREATE TABLE `closing_notes` (
  `id_know` int(11) NOT NULL default '0',
  `created` datetime NOT NULL default '0000-00-00 00:00:00',
  `nik` int(6) default NULL,
  `notes` text,
  PRIMARY KEY  (`id_know`,`created`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `closing_notes`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `confirm`
-- 

CREATE TABLE `confirm` (
  `id_confirm` smallint(1) NOT NULL auto_increment,
  `nm_confirm` varchar(9) default NULL,
  PRIMARY KEY  (`id_confirm`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `confirm`
-- 

INSERT INTO `confirm` VALUES (1, 'Accept');
INSERT INTO `confirm` VALUES (2, 'Tentative');
INSERT INTO `confirm` VALUES (3, 'Decline');
INSERT INTO `confirm` VALUES (4, 'Reject');
INSERT INTO `confirm` VALUES (5, 'Request');
INSERT INTO `confirm` VALUES (6, 'Approve');

-- --------------------------------------------------------

-- 
-- Table structure for table `external_speaker`
-- 

CREATE TABLE `external_speaker` (
  `id_ext_spk` int(11) NOT NULL auto_increment,
  `id_know` int(11) default NULL,
  `nama` varchar(50) default NULL,
  `email` varchar(50) default NULL,
  `telp` varchar(20) default NULL,
  `instansi` varchar(50) default NULL,
  PRIMARY KEY  (`id_ext_spk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `external_speaker`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `inv_status`
-- 

CREATE TABLE `inv_status` (
  `id_inv_status` smallint(1) NOT NULL auto_increment,
  `nm_inv_status` varchar(10) default NULL,
  PRIMARY KEY  (`id_inv_status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `inv_status`
-- 

INSERT INTO `inv_status` VALUES (1, 'Speaker');
INSERT INTO `inv_status` VALUES (2, 'Member');
INSERT INTO `inv_status` VALUES (3, 'Invitee');
INSERT INTO `inv_status` VALUES (4, 'Request');

-- --------------------------------------------------------

-- 
-- Table structure for table `knowledge`
-- 

CREATE TABLE `knowledge` (
  `id_know` int(11) NOT NULL auto_increment,
  `submitter` int(6) default NULL COMMENT 'Submitter',
  `nik` int(6) default NULL,
  `member` varchar(200) default NULL,
  `id_map` smallint(3) default NULL COMMENT 'Knowledge Map',
  `jenis` varchar(15) default NULL,
  `judul` varchar(200) default NULL,
  `t_mulai` datetime default NULL,
  `t_akhir` datetime default NULL,
  `durasi` smallint(3) default NULL COMMENT 'Minute',
  `lokasi` varchar(100) default NULL,
  `unitkerja` varchar(100) default NULL,
  `inv_bidang` text,
  `ext_audience` text,
  `abstraksi` text,
  `harapan` text,
  `referensi` text,
  `req_status` varchar(8) default 'Request' COMMENT 'Request, Reject, Open, Close',
  `app_req_by` int(6) default NULL,
  `app_req_at` datetime default NULL,
  `app_notes` text,
  `report_status` smallint(1) unsigned zerofill default '0' COMMENT '0: Reject, 1: Approve',
  `app_report_by` int(6) default NULL,
  `app_report_at` datetime default NULL,
  `report_notes` text,
  `randomkey` varchar(11) default NULL,
  `created` datetime default NULL,
  `conflict` smallint(1) default NULL COMMENT '1: Conflict, 0: No Conflict',
  PRIMARY KEY  (`id_know`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `knowledge`
-- 

INSERT INTO `knowledge` VALUES (1, 740111, 740111, '', 500, 'Kajian', 'Teknologi Seluler & WiFi untuk Aplikasi Mobile Merchant', '2009-05-26 09:00:00', '2009-05-26 11:00:00', 120, 'Ruang Rapat Lt 4 Menara RDC', 'Lab. Industrial Partnership', '160', '', 'Mobile merchant merupakan salah satu bentuk pembayaran dengan mengunakan media wireless khususnya teknologi seluler. Hal ini telah memberikan solusi baru bagi konsumen dalam melakukan transaksi dengan tingkat keamanan dan fleksibilitas yang tinggi. ', '', '', 'Open', 730373, '2009-05-12 08:22:10', NULL, 0, NULL, NULL, NULL, NULL, '2009-05-12 08:21:47', 0);
INSERT INTO `knowledge` VALUES (2, 750052, 750052, '', 512, 'Standard', 'Wireless LAN untuk Enterprise', '2009-05-26 08:00:00', '2009-05-26 10:00:00', 120, 'Ruang Rapat Lt. 3 Menara RDC', 'Bag. Planning & Business Development', '110', '', 'Teknologi Wireless Local Area Network (Wireless LAN) telah banyak dipakai baik untuk pelangan perumahan, SOHO (Small Office Home Office) dan perkantoran (Enterprise). Dari tipe lokasi tersebut tentunya memiliki karakteristik masing-masing sehingga keuntungan dan model implementasinya berbeda satu dengan lainnnya. Bagi area Enterprise (korporasi), Wireless LAN (WLAN) sudah sangat dianjurkan untuk segera diimplementasikan. Banyak keuntungan yang akan didapat baik yang tangible maupun intangible secara langsung. ', '', '', 'Request', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, '2009-05-12 08:24:33', 1);
INSERT INTO `knowledge` VALUES (3, 730364, 730364, '', 540, 'Kajian', 'Alokasi Pemetaan Spektrum Frekuensi TELKOM', '2009-05-25 15:00:00', '2009-05-25 17:00:00', 120, 'Ruang Rapat RDNM-1', 'Lab. Security & Reliability', '140', '', 'Kajian alokasi pemetaan spektrum frekuensi Telkom menyampaikan perkembangan\r\ndan arah teknologi telekomunikasi yang berbasis penggunaan spektrum frekuensi radio\r\nyang bergerak dengan sangat cepat, regulasi dan alokasi frekuensi yang telah dan akan\r\ndiberikan oleh regulator, serta pemanfaatan alokasi dan lisensi frekuensi yang telah\r\ndidapatkan oleh Telkom. \r\n', 'Penyampaian perkembangan dan arah teknologi komunikasi berbasis frekuensi radio.\r\nPenyampaian perkembangan dan update status regulasi komunikasi berbasis frekuensi.\r\nPenyampaian perkembangan lisensi yang dimiliki Telkom.\r\n', 'Berita perkembangan teknologi komunikasi frekuensi radio.\r\nPerkembangan regulasi komunikasi frekuensi radio dari ITU-R dan BRTI.\r\nPencarian referensi komunikasi frekuensi radio dari bukudan internet.\r\n', 'Request', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, '2009-05-12 08:28:28', 0);
INSERT INTO `knowledge` VALUES (4, 730365, 730365, '', 533, 'Best Practice', 'Konsep Dasar Polymorphism dalam Java', '2009-05-28 13:00:00', '2009-05-28 15:00:00', 120, 'Ruang N22', 'Bag. Service Development', '140,150', '', 'Polymorphism adalah salah satu dari tiga kemampuan yang mendasar yang dimiliki oleh OOP, setelah data abstraction dan inheritance.', '', '', 'Open', 730373, '2009-05-12 09:06:15', NULL, 0, NULL, NULL, NULL, NULL, '2009-05-12 08:33:19', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `knowledge_map`
-- 

CREATE TABLE `knowledge_map` (
  `id_map` smallint(3) NOT NULL,
  `nm_map` varchar(50) default NULL,
  `expert` varchar(50) default NULL,
  `id_top` smallint(3) default NULL,
  `level` smallint(1) default NULL,
  PRIMARY KEY  (`id_map`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `knowledge_map`
-- 

INSERT INTO `knowledge_map` VALUES (100, 'Operation Administration', '', 0, 1);
INSERT INTO `knowledge_map` VALUES (110, 'Supply Management', NULL, 100, 2);
INSERT INTO `knowledge_map` VALUES (111, 'Procurement', 'I Ketut Yadnya', 110, 3);
INSERT INTO `knowledge_map` VALUES (112, 'Asset Management', 'I Ketut Yadnya', 110, 3);
INSERT INTO `knowledge_map` VALUES (120, 'Secretary Management', 'Widi Rusmiyanta', 100, 2);
INSERT INTO `knowledge_map` VALUES (130, 'Legal', 'Edy', 100, 2);
INSERT INTO `knowledge_map` VALUES (200, 'Business', NULL, 0, 1);
INSERT INTO `knowledge_map` VALUES (210, 'Portfolio Business Analysis', NULL, 200, 2);
INSERT INTO `knowledge_map` VALUES (211, 'Product Management', 'Ratih Rufianti', 210, 3);
INSERT INTO `knowledge_map` VALUES (212, 'Industry Analysis', 'Lamhot Simamora', 210, 3);
INSERT INTO `knowledge_map` VALUES (213, 'Competitiveness Analysis', 'Paulus Hutagaol', 210, 3);
INSERT INTO `knowledge_map` VALUES (220, 'Business Model & Planning', NULL, 200, 2);
INSERT INTO `knowledge_map` VALUES (221, 'Business Strategy', 'Lamhot Simamora', 220, 3);
INSERT INTO `knowledge_map` VALUES (222, 'Market Strategy', 'Henry Setiawan', 220, 3);
INSERT INTO `knowledge_map` VALUES (223, 'Value Chain Management', 'Lamhot Simamora', 220, 3);
INSERT INTO `knowledge_map` VALUES (224, 'Financial Feasibility Analysis', 'Meinanda', 220, 3);
INSERT INTO `knowledge_map` VALUES (225, 'Technology Management', 'Wiseto', 220, 3);
INSERT INTO `knowledge_map` VALUES (226, 'Partnership Analysis', 'Johannes Adi', 220, 3);
INSERT INTO `knowledge_map` VALUES (230, 'Marketing', NULL, 200, 2);
INSERT INTO `knowledge_map` VALUES (231, 'Marketing Plan', 'Faisal', 230, 3);
INSERT INTO `knowledge_map` VALUES (232, 'STP', 'Faisal', 230, 3);
INSERT INTO `knowledge_map` VALUES (233, 'Branding', 'Faisal', 230, 3);
INSERT INTO `knowledge_map` VALUES (234, 'Market & Demand Analysis', 'Fentiani', 230, 3);
INSERT INTO `knowledge_map` VALUES (300, 'Governance', NULL, 0, 1);
INSERT INTO `knowledge_map` VALUES (310, 'Project Management', NULL, 300, 2);
INSERT INTO `knowledge_map` VALUES (320, 'Research Methodology', NULL, 300, 2);
INSERT INTO `knowledge_map` VALUES (330, 'Human Resource Management', NULL, 300, 2);
INSERT INTO `knowledge_map` VALUES (331, 'HR Plan & Strategy', 'Prasetiawan', 330, 3);
INSERT INTO `knowledge_map` VALUES (332, 'Competency Management', 'Gatot Imam Sukoco', 330, 3);
INSERT INTO `knowledge_map` VALUES (333, 'Organisation & Culture', 'Nurdjaya', 330, 3);
INSERT INTO `knowledge_map` VALUES (334, 'Change Management', 'Nurdjaya', 330, 3);
INSERT INTO `knowledge_map` VALUES (340, 'Finance', NULL, 300, 2);
INSERT INTO `knowledge_map` VALUES (341, 'Budgeting', 'Laksono', 340, 3);
INSERT INTO `knowledge_map` VALUES (342, 'Tariff & Costing', 'Abdul Muis', 340, 3);
INSERT INTO `knowledge_map` VALUES (350, 'Planning', NULL, 300, 2);
INSERT INTO `knowledge_map` VALUES (351, 'Strategic & Program Planning', 'Meinanda K', 350, 3);
INSERT INTO `knowledge_map` VALUES (352, 'Resource Planning', 'Prasetiawan', 350, 3);
INSERT INTO `knowledge_map` VALUES (353, 'Process Management & Tools', 'Gatot Imam Sukoco', 350, 3);
INSERT INTO `knowledge_map` VALUES (354, 'Risk Management', 'Prasetiawan', 350, 3);
INSERT INTO `knowledge_map` VALUES (360, 'Performance Management', NULL, 300, 2);
INSERT INTO `knowledge_map` VALUES (361, 'Management System Evaluation', 'Nurdjaya', 360, 3);
INSERT INTO `knowledge_map` VALUES (362, 'Performance Measurement, Evaluation & Reporting', 'Luk Lu''ul Ilma', 360, 3);
INSERT INTO `knowledge_map` VALUES (370, 'Quality Management', NULL, 300, 2);
INSERT INTO `knowledge_map` VALUES (371, 'Quality System', 'Tyas Indah TH', 370, 3);
INSERT INTO `knowledge_map` VALUES (372, 'Innovation Management', 'Melani', 370, 3);
INSERT INTO `knowledge_map` VALUES (380, 'Partnership', NULL, 300, 2);
INSERT INTO `knowledge_map` VALUES (381, 'Joint Research & Development', 'Budi Supardiman', 380, 3);
INSERT INTO `knowledge_map` VALUES (382, 'Community Development', 'Andreas W.Y', 380, 3);
INSERT INTO `knowledge_map` VALUES (400, 'Personal Quality', NULL, 0, 1);
INSERT INTO `knowledge_map` VALUES (410, 'Presentation Skill', 'Kamariah L', 400, 2);
INSERT INTO `knowledge_map` VALUES (420, 'Problem & Decision Analysis', 'Lamhot Simamora', 400, 2);
INSERT INTO `knowledge_map` VALUES (430, 'Document Writing', 'Gunadi', 400, 2);
INSERT INTO `knowledge_map` VALUES (440, 'Communication Skill', 'Ari Wibowo', 400, 2);
INSERT INTO `knowledge_map` VALUES (500, 'Technology', '', 0, 1);
INSERT INTO `knowledge_map` VALUES (510, 'Core Network', '', 500, 2);
INSERT INTO `knowledge_map` VALUES (511, 'Optic Transmission', 'Lesmin Nainggolan', 510, 3);
INSERT INTO `knowledge_map` VALUES (512, 'Data Network', 'Fidar Aji Laksono', 510, 3);
INSERT INTO `knowledge_map` VALUES (513, 'Softswitch', 'Iwan Gunawan', 510, 3);
INSERT INTO `knowledge_map` VALUES (514, 'IMS', 'Angkoso', 510, 3);
INSERT INTO `knowledge_map` VALUES (515, 'MSCe', 'Azwir', 510, 3);
INSERT INTO `knowledge_map` VALUES (520, 'Access', '', 500, 2);
INSERT INTO `knowledge_map` VALUES (521, 'Broadband Wireline System', 'Ariyanto', 520, 3);
INSERT INTO `knowledge_map` VALUES (522, 'OSP & Operation Maintenance Support System', 'Sugeng', 520, 3);
INSERT INTO `knowledge_map` VALUES (523, 'Wireless', 'Denny Sukarman', 520, 3);
INSERT INTO `knowledge_map` VALUES (530, 'Service & Application', '', 500, 2);
INSERT INTO `knowledge_map` VALUES (531, 'Service & Application Paltform', 'Chandra T', 530, 3);
INSERT INTO `knowledge_map` VALUES (532, 'Service & Application Design', 'Fridh Zuriyadi', 530, 3);
INSERT INTO `knowledge_map` VALUES (533, 'Software & Application Engineering', 'Sigit H.P', 530, 3);
INSERT INTO `knowledge_map` VALUES (540, 'TMN', '', 500, 2);
INSERT INTO `knowledge_map` VALUES (541, 'Operation Support System', 'Bengris Pasaribu', 540, 3);
INSERT INTO `knowledge_map` VALUES (542, 'Business Support System', 'Guritno', 540, 3);
INSERT INTO `knowledge_map` VALUES (543, 'Customer Support System', 'Adi Permadi', 540, 3);
INSERT INTO `knowledge_map` VALUES (544, 'Network Management Protocol', 'Heru Irman', 540, 3);
INSERT INTO `knowledge_map` VALUES (545, 'Enterprise Application Interface', 'Sri Ponco', 540, 3);
INSERT INTO `knowledge_map` VALUES (546, 'Network Management Modeling', 'Ahmed Yasser', 540, 3);
INSERT INTO `knowledge_map` VALUES (550, 'Security & Numbering', '', 500, 2);
INSERT INTO `knowledge_map` VALUES (551, 'Network Security', 'Adi Permadi ', 550, 3);
INSERT INTO `knowledge_map` VALUES (552, 'Application Security', 'Asep Priyanto', 550, 3);
INSERT INTO `knowledge_map` VALUES (553, 'Revenue Assurance', 'Sovan Hadibowo', 550, 3);
INSERT INTO `knowledge_map` VALUES (554, 'Numbering System', 'Yusril Sini', 550, 3);
INSERT INTO `knowledge_map` VALUES (560, 'CPE', '', 500, 2);
INSERT INTO `knowledge_map` VALUES (561, 'Wireless', 'Joni Handoyo', 560, 3);
INSERT INTO `knowledge_map` VALUES (562, 'Wireline', 'Ariyanto', 560, 3);
INSERT INTO `knowledge_map` VALUES (570, 'Signaling', '', 500, 2);
INSERT INTO `knowledge_map` VALUES (571, 'Signaling VAS', 'Ibnu Alinursafa', 570, 3);
INSERT INTO `knowledge_map` VALUES (572, 'Signaling Core Network', 'Beni Triantono', 570, 3);
INSERT INTO `knowledge_map` VALUES (573, 'Signaling Access Network', 'Moch. Suharyanto', 570, 3);
INSERT INTO `knowledge_map` VALUES (580, 'Supporting Facilities', '', 500, 2);
INSERT INTO `knowledge_map` VALUES (581, 'Electrical', 'Suharjanto Mulyono', 580, 3);
INSERT INTO `knowledge_map` VALUES (582, 'Mechanical', 'Johanes Suharsono', 580, 3);
INSERT INTO `knowledge_map` VALUES (583, 'Civil', 'Suharjanto Mulyono', 580, 3);
INSERT INTO `knowledge_map` VALUES (590, 'Equipment Testing', '', 500, 2);
INSERT INTO `knowledge_map` VALUES (591, 'Mechanical & Electrical Measurement', 'Tri Susanto', 590, 3);
INSERT INTO `knowledge_map` VALUES (592, 'CPE & Switch Measurement', 'Nur''ain', 590, 3);
INSERT INTO `knowledge_map` VALUES (593, 'Transmission Measurement', 'Kusno Windarwanto', 590, 3);
INSERT INTO `knowledge_map` VALUES (594, 'Calibration Measurement', 'Setyo Hadi Hernowo', 590, 3);
INSERT INTO `knowledge_map` VALUES (595, 'Cable & Fiber Optiv Measurement', 'Nofrial', 590, 3);

-- --------------------------------------------------------

-- 
-- Table structure for table `loker`
-- 

CREATE TABLE `loker` (
  `id_loker` smallint(3) NOT NULL,
  `nm_loker` varchar(100) default NULL,
  `acronym` varchar(4) default NULL,
  `id_top` smallint(3) default NULL,
  PRIMARY KEY  (`id_loker`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `loker`
-- 

INSERT INTO `loker` VALUES (100, 'TELKOM RDC', 'RDC', 0);
INSERT INTO `loker` VALUES (101, 'Senior General Manager TELKOM RDC', 'SGM', 100);
INSERT INTO `loker` VALUES (110, 'Bidang Planning & Controlling', 'PNC', 100);
INSERT INTO `loker` VALUES (111, 'Bag. Planning & Business Development', 'PNBD', 110);
INSERT INTO `loker` VALUES (112, 'Bag. Quality Management', 'QM', 110);
INSERT INTO `loker` VALUES (113, 'Bag. Performance Management', 'PM', 110);
INSERT INTO `loker` VALUES (120, 'Bidang General Support', 'GS', 100);
INSERT INTO `loker` VALUES (121, 'Bag. Secretariate', 'SC', 120);
INSERT INTO `loker` VALUES (122, 'Bag. Logistic & Asset Management', 'LOG', 120);
INSERT INTO `loker` VALUES (123, 'Bag. User Relation', 'UREL', 120);
INSERT INTO `loker` VALUES (124, 'Bag. Data & IT Support', 'DITS', 120);
INSERT INTO `loker` VALUES (130, 'Bidang R&D of Infrastructure', 'RDI', 100);
INSERT INTO `loker` VALUES (131, 'Lab. Service Nodes', 'SN', 130);
INSERT INTO `loker` VALUES (132, 'Lab. Transmission', 'TR', 130);
INSERT INTO `loker` VALUES (133, 'Lab. Wireline Network', 'WNN', 130);
INSERT INTO `loker` VALUES (134, 'Lab. Wireless Network', 'WSN', 130);
INSERT INTO `loker` VALUES (135, 'Lab. Signalling & Integration', 'SNI', 130);
INSERT INTO `loker` VALUES (140, 'Bidang R&D of Network Management', 'RDNM', 100);
INSERT INTO `loker` VALUES (141, 'Lab. TMN', 'TMN', 140);
INSERT INTO `loker` VALUES (142, 'Lab. Security & Reliability', 'SNR', 140);
INSERT INTO `loker` VALUES (143, 'Lab. Technical Compliance', 'TC', 140);
INSERT INTO `loker` VALUES (144, 'Lab. QA Infrastructure', 'INF', 140);
INSERT INTO `loker` VALUES (145, 'Lab. QA CPE & Support', 'CPE', 140);
INSERT INTO `loker` VALUES (150, 'Bidang R&D of Service & Product', 'RDSP', 100);
INSERT INTO `loker` VALUES (151, 'Bag. Service & Product Planning', 'SNPP', 150);
INSERT INTO `loker` VALUES (152, 'Bag. Service Development', 'SD', 150);
INSERT INTO `loker` VALUES (153, 'Bag. Product Development', 'PD', 150);
INSERT INTO `loker` VALUES (154, 'Bag. Solution Enterprise', 'SE', 150);
INSERT INTO `loker` VALUES (160, 'Bidang Research of Business', 'ROB', 100);
INSERT INTO `loker` VALUES (161, 'Lab. Business Strategy Research', 'BSR', 160);
INSERT INTO `loker` VALUES (162, 'Lab. Business Performance', 'BP', 160);
INSERT INTO `loker` VALUES (163, 'Lab. Business Competitive', 'BC', 160);
INSERT INTO `loker` VALUES (164, 'Lab. Industrial Partnership', 'IP', 160);

-- --------------------------------------------------------

-- 
-- Table structure for table `master_poin`
-- 

CREATE TABLE `master_poin` (
  `id_now` smallint(2) NOT NULL,
  `id_poin` smallint(1) NOT NULL,
  `poin` smallint(2) default NULL,
  `active` smallint(1) default NULL,
  PRIMARY KEY  (`id_now`,`id_poin`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `master_poin`
-- 

INSERT INTO `master_poin` VALUES (1, 1, 10, 1);
INSERT INTO `master_poin` VALUES (1, 2, 15, 1);
INSERT INTO `master_poin` VALUES (1, 3, 20, 1);
INSERT INTO `master_poin` VALUES (1, 4, 30, 1);
INSERT INTO `master_poin` VALUES (1, 5, 2, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `notification`
-- 

CREATE TABLE `notification` (
  `id_not` varchar(32) NOT NULL default '',
  `id_know` int(11) default NULL,
  `created` datetime default NULL,
  `subject` varchar(50) default NULL,
  `link` varchar(200) default NULL,
  `status` smallint(1) default '1',
  PRIMARY KEY  (`id_not`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `notification`
-- 

INSERT INTO `notification` VALUES ('42d921e5d7e14b1a0775f28c4d115cf1', 1, '2009-05-12 08:21:47', 'Request Sharing', NULL, 1);
INSERT INTO `notification` VALUES ('a8fd2baab06eff4e559b85cf76d5a791', 2, '2009-05-12 08:24:33', 'Request Sharing', NULL, 1);
INSERT INTO `notification` VALUES ('e8a11deb78b998cf35eb4dc6632658a3', 3, '2009-05-12 08:28:28', 'Request Sharing', NULL, 1);
INSERT INTO `notification` VALUES ('9c2b1711bd37bf7466105af0b978ad88', 4, '2009-05-12 08:33:19', 'Request Sharing', NULL, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `notification_4nik`
-- 

CREATE TABLE `notification_4nik` (
  `id_not` varchar(32) NOT NULL,
  `nik` int(6) NOT NULL,
  PRIMARY KEY  (`id_not`,`nik`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `notification_4nik`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `profile`
-- 

CREATE TABLE `profile` (
  `id_profile` smallint(1) NOT NULL auto_increment,
  `nm_profile` varchar(13) default NULL,
  PRIMARY KEY  (`id_profile`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `profile`
-- 

INSERT INTO `profile` VALUES (1, 'Administrator');
INSERT INTO `profile` VALUES (2, 'Committee');
INSERT INTO `profile` VALUES (3, 'Common User');

-- --------------------------------------------------------

-- 
-- Table structure for table `rapor_bidang`
-- 

CREATE TABLE `rapor_bidang` (
  `year` smallint(4) NOT NULL,
  `id_bidang` smallint(3) NOT NULL,
  `total_point` smallint(4) default NULL,
  PRIMARY KEY  (`year`,`id_bidang`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `rapor_bidang`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `rapor_individu`
-- 

CREATE TABLE `rapor_individu` (
  `year` smallint(4) NOT NULL,
  `nik` int(6) NOT NULL,
  `total_point` smallint(3) default NULL,
  PRIMARY KEY  (`year`,`nik`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `rapor_individu`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `req_to_attend`
-- 

CREATE TABLE `req_to_attend` (
  `id` int(11) NOT NULL auto_increment,
  `id_know` int(11) default NULL,
  `email` varchar(50) default NULL,
  `created` datetime default NULL,
  `id_status` smallint(1) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `req_to_attend`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `schedule`
-- 

CREATE TABLE `schedule` (
  `id_know` int(11) NOT NULL,
  `t_mulai` datetime default NULL,
  `t_akhir` datetime default NULL,
  `durasi` int(3) default NULL,
  `statusnya` varchar(5) default NULL,
  PRIMARY KEY  (`id_know`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `schedule`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `sharing_act_ext`
-- 

CREATE TABLE `sharing_act_ext` (
  `id` int(11) NOT NULL auto_increment,
  `id_know` int(11) default NULL,
  `email` varchar(100) default NULL,
  `attend` smallint(1) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `sharing_act_ext`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `sharing_activity`
-- 

CREATE TABLE `sharing_activity` (
  `id_know` int(11) NOT NULL,
  `nik` int(6) NOT NULL,
  `id_confirm` smallint(1) default '0',
  `id_inv_status` smallint(1) default NULL,
  `attend` smallint(1) default '0',
  `poin` int(3) default NULL,
  PRIMARY KEY  (`id_know`,`nik`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `sharing_activity`
-- 

INSERT INTO `sharing_activity` VALUES (1, 740111, 1, 1, 1, NULL);
INSERT INTO `sharing_activity` VALUES (1, 602217, 0, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (1, 660229, 0, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (1, 660152, 0, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (4, 730365, 1, 1, 1, NULL);
INSERT INTO `sharing_activity` VALUES (4, 602217, 0, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (4, 720088, 0, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (4, 633086, 0, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (4, 730364, 0, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (4, 730373, 1, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (4, 750046, 0, 3, 0, NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `sharing_notes`
-- 

CREATE TABLE `sharing_notes` (
  `id_know` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `nik` int(6) default NULL,
  `notes` text,
  PRIMARY KEY  (`id_know`,`created`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `sharing_notes`
-- 

INSERT INTO `sharing_notes` VALUES (4, '2009-05-12 09:06:15', 730373, 'Jadwal Anda berubah dari tanggal 25 Mei 2009 diundur menjadi tanggal 28 Mei 2009');

-- --------------------------------------------------------

-- 
-- Table structure for table `subject`
-- 

CREATE TABLE `subject` (
  `id_subject` smallint(2) NOT NULL auto_increment,
  `nm_subject` varchar(50) default NULL,
  `message` text,
  PRIMARY KEY  (`id_subject`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `subject`
-- 

INSERT INTO `subject` VALUES (1, 'Request Sharing', 'This is request from ');
INSERT INTO `subject` VALUES (2, 'Request Sharing', 'Your request ');
INSERT INTO `subject` VALUES (3, 'Closing Task', 'Please close your task.');
INSERT INTO `subject` VALUES (4, 'Request to Attend', '');
INSERT INTO `subject` VALUES (5, 'Report', 'Your Report ');

-- --------------------------------------------------------

-- 
-- Table structure for table `upload`
-- 

CREATE TABLE `upload` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  `type` varchar(30) NOT NULL default '',
  `size` int(11) NOT NULL default '0',
  `path` varchar(200) NOT NULL default '',
  `randomkey` varchar(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `upload`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `user`
-- 

CREATE TABLE `user` (
  `nik` int(6) NOT NULL,
  `nama` varchar(100) default NULL,
  `band` varchar(3) default NULL,
  `posisi` varchar(100) default NULL,
  `id_bidang` smallint(3) default NULL,
  `id_loker` smallint(3) default NULL,
  `email` varchar(100) default NULL,
  `id_profile` smallint(1) default NULL,
  `active` smallint(1) default '1',
  PRIMARY KEY  (`nik`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `user`
-- 

INSERT INTO `user` VALUES (651176, 'Asep Priyanto', NULL, NULL, 120, 124, 'asep_p@telkom.co.id', 1, 1);
INSERT INTO `user` VALUES (660229, 'Fentiani', NULL, NULL, 160, 163, 'fenti@telkom.co.id', 1, 1);
INSERT INTO `user` VALUES (720088, 'Ahmed Yasser', NULL, NULL, 140, 140, 'yasser@telkom.co.id', 1, 1);
INSERT INTO `user` VALUES (730373, 'Fridh Zurriyadi Ridwan', NULL, NULL, 150, 150, 'fridh@telkom.co.id', 1, 1);
INSERT INTO `user` VALUES (602217, 'Mustapa Wangsaatmadja', NULL, NULL, 100, 101, 'mustapa@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (710439, 'Laksono Sugeng Santoso', NULL, NULL, 110, 111, 'laksono_ss@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (750052, 'Meinanda Kurniawan', NULL, NULL, 110, 111, 'meinanda@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (660454, 'Kuatin', NULL, NULL, 120, 121, 'kuatin@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (650719, 'Hary Sugiarso', NULL, NULL, 120, 124, 'haes@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730590, 'Dian Agung Nugroho', NULL, NULL, 130, 135, 'agung_n@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (750053, 'Angkoso Suryocahyono', NULL, NULL, 130, 131, 'angkoso@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (633086, 'Bengris Pasaribu', NULL, NULL, 140, 141, 'pasaribu@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730364, 'Darso', NULL, NULL, 140, 142, 'darso@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730365, 'Anung Asmoro', NULL, NULL, 150, 152, 'anung@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (750046, 'Indri Sonwaskito', NULL, NULL, 150, 153, 'indrison@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (660152, 'Bambang Achiranto', NULL, NULL, 160, 164, 'achir@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (740111, 'Andreas Widiasmono Yanuardi', NULL, NULL, 160, 164, 'andreas_w@telkom.co.id', 3, 1);
