-- phpMyAdmin SQL Dump
-- version 2.8.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: May 07, 2009 at 11:27 AM
-- Server version: 5.0.22
-- PHP Version: 5.1.4

DROP DATABASE IF EXISTS `kmore`;

CREATE DATABASE `kmore`;

USE `kmore`;

-- 
-- Database: `kmore`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `bidang`
-- 

CREATE TABLE `bidang` (
  `id_bidang` smallint(3) NOT NULL,
  `nm_bidang` varchar(100) default NULL,
  `singkatan` varchar(4) default NULL,
  `email` varchar(100) default NULL,
  PRIMARY KEY  (`id_bidang`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `bidang`
-- 

INSERT INTO `bidang` VALUES (120, 'Bidang Planning & Controlling', 'RDI', 'rdc_rdi@telkom.co.id');
INSERT INTO `bidang` VALUES (100, 'TELKOM RDC', 'RDC', 'rdc_sgm@telkom.co.id');
INSERT INTO `bidang` VALUES (110, 'General Support', 'GS', 'rdc_gs@telkom.co.id');
INSERT INTO `bidang` VALUES (130, 'Bidang R&D of Infrastructure', 'PNC', 'rdc_pnc@telkom.co.id');
INSERT INTO `bidang` VALUES (140, 'Bidang R&D of Network Management', 'RDNM', 'rdc_rdnm@telkom.co.id');
INSERT INTO `bidang` VALUES (150, 'Bidang R&D of Service & Product', 'RDSP', 'rdc_rdsp@telkom.co.id');
INSERT INTO `bidang` VALUES (160, 'Bidang Research of Business', 'ROB', 'rdc_rob@telkom.co.id');

-- --------------------------------------------------------

-- 
-- Table structure for table `confirm`
-- 

CREATE TABLE `confirm` (
  `id_confirm` smallint(1) NOT NULL auto_increment,
  `nm_confirm` varchar(9) default NULL,
  PRIMARY KEY  (`id_confirm`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `confirm`
-- 

INSERT INTO `confirm` VALUES (1, 'Accept');
INSERT INTO `confirm` VALUES (2, 'Tentative');
INSERT INTO `confirm` VALUES (3, 'Decline');
INSERT INTO `confirm` VALUES (4, 'Reject');

-- --------------------------------------------------------

-- 
-- Table structure for table `external_speaker`
-- 

CREATE TABLE `external_speaker` (
  `id_ext_spk` int(11) NOT NULL auto_increment,
  `id_know` int(11) default NULL,
  `nama` varchar(50) default NULL,
  `email` varchar(50) default NULL,
  `telp` varchar(20) default NULL,
  `instansi` varchar(50) default NULL,
  PRIMARY KEY  (`id_ext_spk`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `external_speaker`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `inv_status`
-- 

CREATE TABLE `inv_status` (
  `id_inv_status` smallint(1) NOT NULL auto_increment,
  `nm_inv_status` varchar(10) default NULL,
  PRIMARY KEY  (`id_inv_status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `inv_status`
-- 

INSERT INTO `inv_status` VALUES (1, 'Speaker');
INSERT INTO `inv_status` VALUES (2, 'Member');
INSERT INTO `inv_status` VALUES (3, 'Invitee');
INSERT INTO `inv_status` VALUES (4, 'Request');

-- --------------------------------------------------------

-- 
-- Table structure for table `knowledge`
-- 

CREATE TABLE `knowledge` (
  `id_know` int(11) NOT NULL auto_increment,
  `submitter` int(6) default NULL COMMENT 'Submitter',
  `nik` int(6) default NULL,
  `member` varchar(200) default NULL,
  `id_map` smallint(3) default NULL COMMENT 'Knowledge Map',
  `jenis` varchar(15) default NULL,
  `judul` varchar(200) default NULL,
  `t_mulai` datetime default NULL,
  `t_akhir` datetime default NULL,
  `durasi` smallint(3) default NULL COMMENT 'Minute',
  `lokasi` varchar(100) default NULL,
  `unitkerja` varchar(100) default NULL,
  `inv_bidang` text,
  `ext_audience` text,
  `abstraksi` text,
  `harapan` text,
  `referensi` text,
  `req_status` varchar(8) default 'Request' COMMENT 'Request, Reject, Open, Close',
  `app_req_by` int(6) default NULL,
  `app_req_at` datetime default NULL,
  `app_notes` text,
  `report_status` smallint(1) unsigned zerofill default '0' COMMENT '0: Reject, 1: Approve',
  `app_report_by` int(6) default NULL,
  `app_report_at` datetime default NULL,
  `report_notes` text,
  `randomkey` varchar(11) default NULL,
  `created` datetime default NULL,
  PRIMARY KEY  (`id_know`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `knowledge`
-- 

INSERT INTO `knowledge` VALUES (1, 740111, 740111, '680151,660152', 544, 'Kajian', 'Cross-Layer: Fenomena dan Keberadaannya di Dunia Penelitian dan Industri', '2009-05-06 08:00:00', '2009-05-06 10:00:00', 150, 'Ruang Rapat Lt 4 Menara RDC', 'Lab. Industrial Partnership', '101,160', NULL, 'Cross-layer yang merupakan salah satu penelitian yang ramai dibicarakan belakangan ini. Isu cross-layer yang baru itu mulai dibahas di text book sejak tahun 2006. Isu ini menjadi penting, terlebih pada peer-to-peer communications maupun pada sensor communications di bidang wireless communications.', 'Melalui cross-layer protocol design dimungkinkan adanya komunikasi antara non-adjacent layers sebagai suatu extension dari model yang ada sebelumnya, yaitu OSI model.', '1. Fitzek, Frank H.P. dan Frank Reichert: 2007. "Mobile Phone Programming and its Application to Wireless Networking. Springer, USA.\r\n2. Glisic, Savo G.: 2006. "Advanced Wireless Networks: 4G Technologies". John Wiley & Sons Ltd, UK.\r\n3. Goldsmith, Andrea: 2005. "WIRELESS COMMUNICATIONS". Cambridge University Press, USA. ', 'Close', 730373, '2009-05-04 11:12:41', NULL, 1, NULL, NULL, NULL, '7829503Fz', '2009-05-04 09:56:48');
INSERT INTO `knowledge` VALUES (2, 730364, 730364, '', 523, 'Standard', 'Alokasi Pemetaan Spektrum Frekuensi TELKOM', '2009-05-19 09:00:00', '2009-05-19 11:00:00', 120, 'Ruang Rapat RDNM-1', 'Lab. Security & Reliability', '101,140', NULL, 'Kajian alokasi pemetaan spektrum frekuensi Telkom menyampaikan perkembangan\r\ndan arah teknologi telekomunikasi yang berbasis penggunaan spektrum frekuensi radio\r\nyang bergerak dengan sangat cepat, regulasi dan alokasi frekuensi yang telah dan akan\r\ndiberikan oleh regulator, serta pemanfaatan alokasi dan lisensi frekuensi yang telah\r\ndidapatkan oleh Telkom. \r\n', 'Penyampaian perkembangan dan arah teknologi komunikasi berbasis frekuensi radio.\r\nPenyampaian perkembangan dan update status regulasi komunikasi berbasis frekuensi.\r\nPenyampaian perkembangan lisensi yang dimiliki Telkom.\r\n', 'Berita perkembangan teknologi komunikasi frekuensi radio.\r\nPerkembangan regulasi komunikasi frekuensi radio dari ITU-R dan BRTI.\r\nPencarian referensi komunikasi frekuensi radio dari bukudan internet.\r\n', 'Request', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, '2009-05-04 09:59:58');
INSERT INTO `knowledge` VALUES (3, 710439, 710439, '720592', 512, 'Best Practice', 'SSL VPN (Secure Socket Layer Virtual Private Network)', '2009-05-25 14:00:00', '2009-05-25 16:00:00', 120, 'Ruang N21', 'Bag. Planning & Business Development', '101,110', '', 'Dalam lingkungan bisnis yang bergerak cepat saat ini, suatu perusahaan membutuhkan sarana komunikasi yang memiliki cakupan dan tingkat ketersediaan yang tinggi. SSL VPN merupakan salah satu solusi dengan menggunakan jaringan internet yang sudah tersedia. Dibandingkan jaringan leased lines atau frame relay, SSL VPN menggunakan infrastruktur yang sudah ada di internet untuk melakukan pertukaran data antara kantor pusat sebuah perusahaan dan kantor cabangnya.', 'Teknologi SSL VPN merupakan teknologi yang memungkinkan bagi pengguna/remote site dalam bentuk PC (personal computer, termasuk PDA dengan kapabilitas SSL). Dengan diimplementasikannya teknologi SSL maka operator IP perlu melakuan kajian dan analisa terhadap peluang pendapatan dan keuntungan terhadap kebutuhan investasi teknologi tersebut, melalui beberapa informasi vendor (RFI), trial performansi sistem ataupun POC (Prove of Concept) untuk kebutuhan implementasi akan berjalan dengan baik.', '    * http://www.cisco.com/\r\n    * http://www.juniper.net/products_and_services/ssl_vpn_secure_access/\r\n    * Understanding SSL VPN, Packt Publishing, Joseph Steinberg , http://sslvpnbook.packtpub.com/\r\n    * SSL VPNs come of age, http://www.lightreading.com.\r\n    * SSL VPNs: Access Anywhere, Anytime, http://www.lightreading.com. ', 'Open', 730373, '2009-05-04 16:29:47', NULL, 0, NULL, NULL, NULL, NULL, '2009-05-04 11:23:08');
INSERT INTO `knowledge` VALUES (4, 740111, 740111, '660152, ,', 223, 'Standard', 'Neque porro quisquam', '2009-05-08 08:30:00', '2009-05-08 10:30:00', 120, 'Ruang Rapat RoB Lt 4 Menara RDC', 'Lab. Industrial Partnership', '101,160', 'aaa@telkom.co.id, bbb@telkom.co.id', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut augue ipsum, cursus a, varius nec, sodales et, magna. Integer cursus lacinia ligula. Praesent elementum faucibus justo. Quisque nulla mauris, mollis pharetra, luctus at, vehicula ac, erat.', 'Nullam dignissim euismod dui. Phasellus convallis, tortor sit amet convallis condimentum, libero lectus venenatis sapien, ut euismod ante nisl id libero. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tellus nisl, ultrices eget, vehicula vel, pulvinar in, dui.', 'Donec iaculis mollis nisi. Pellentesque consequat sem ut diam. Aliquam posuere bibendum ipsum. Suspendisse porta lectus vel dolor. Cras fermentum. Sed orci ligula, fermentum at, aliquet vel, ultrices ac, dui. Donec enim dui, rutrum quis, cursus ac, luctus vel, dui. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nulla odio. Cras vitae elit non lorem accumsan sagittis.', 'Request', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, '2009-05-04 17:03:03');
INSERT INTO `knowledge` VALUES (5, 730365, 730365, '', 200, 'ds', 'test', '2009-05-28 08:00:00', '2009-05-28 09:00:00', 60, 'ds', 'Bag. Service Development', '110,120,130,150', 'a', 'sa', '', 'sa', 'Open', 730373, '2009-05-04 17:12:45', NULL, 0, NULL, NULL, NULL, NULL, '2009-05-04 17:07:36');
INSERT INTO `knowledge` VALUES (6, 740111, 740111, '', 222, 'Standard', 'coba coba coba', '2009-05-26 09:00:00', '2009-05-26 11:30:00', 150, 'Ruang N22', 'Lab. Industrial Partnership', '101,160', '', 'halo halo halo', 'hore hore hore', 'hula hula hula', 'Request', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, '2009-05-05 14:12:57');

-- --------------------------------------------------------

-- 
-- Table structure for table `knowledge_map`
-- 

CREATE TABLE `knowledge_map` (
  `id_map` smallint(3) NOT NULL,
  `nm_map` varchar(50) default NULL,
  `expert` varchar(50) default NULL,
  `id_top` smallint(3) default NULL,
  `level` smallint(1) default NULL,
  PRIMARY KEY  (`id_map`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `knowledge_map`
-- 

INSERT INTO `knowledge_map` VALUES (100, 'Operation Administration', '', 0, 1);
INSERT INTO `knowledge_map` VALUES (110, 'Supply Management', NULL, 100, 2);
INSERT INTO `knowledge_map` VALUES (111, 'Procurement', 'I Ketut Yadnya', 110, 3);
INSERT INTO `knowledge_map` VALUES (112, 'Asset Management', 'I Ketut Yadnya', 110, 3);
INSERT INTO `knowledge_map` VALUES (120, 'Secretary Management', 'Widi Rusmiyanta', 100, 2);
INSERT INTO `knowledge_map` VALUES (130, 'Legal', 'Edy', 100, 2);
INSERT INTO `knowledge_map` VALUES (200, 'Business', NULL, 0, 1);
INSERT INTO `knowledge_map` VALUES (210, 'Portfolio Business Analysis', NULL, 200, 2);
INSERT INTO `knowledge_map` VALUES (211, 'Product Management', 'Ratih Rufianti', 210, 3);
INSERT INTO `knowledge_map` VALUES (212, 'Industry Analysis', 'Lamhot Simamora', 210, 3);
INSERT INTO `knowledge_map` VALUES (213, 'Competitiveness Analysis', 'Paulus Hutagaol', 210, 3);
INSERT INTO `knowledge_map` VALUES (220, 'Business Model & Planning', NULL, 200, 2);
INSERT INTO `knowledge_map` VALUES (221, 'Business Strategy', 'Lamhot Simamora', 220, 3);
INSERT INTO `knowledge_map` VALUES (222, 'Market Strategy', 'Henry Setiawan', 220, 3);
INSERT INTO `knowledge_map` VALUES (223, 'Value Chain Management', 'Lamhot Simamora', 220, 3);
INSERT INTO `knowledge_map` VALUES (224, 'Financial Feasibility Analysis', 'Meinanda', 220, 3);
INSERT INTO `knowledge_map` VALUES (225, 'Technology Management', 'Wiseto', 220, 3);
INSERT INTO `knowledge_map` VALUES (226, 'Partnership Analysis', 'Johannes Adi', 220, 3);
INSERT INTO `knowledge_map` VALUES (230, 'Marketing', NULL, 200, 2);
INSERT INTO `knowledge_map` VALUES (231, 'Marketing Plan', 'Faisal', 230, 3);
INSERT INTO `knowledge_map` VALUES (232, 'STP', 'Faisal', 230, 3);
INSERT INTO `knowledge_map` VALUES (233, 'Branding', 'Faisal', 230, 3);
INSERT INTO `knowledge_map` VALUES (234, 'Market & Demand Analysis', 'Fentiani', 230, 3);
INSERT INTO `knowledge_map` VALUES (300, 'Governance', NULL, 0, 1);
INSERT INTO `knowledge_map` VALUES (310, 'Project Management', NULL, 300, 2);
INSERT INTO `knowledge_map` VALUES (320, 'Research Methodology', NULL, 300, 2);
INSERT INTO `knowledge_map` VALUES (330, 'Human Resource Management', NULL, 300, 2);
INSERT INTO `knowledge_map` VALUES (331, 'HR Plan & Strategy', 'Prasetiawan', 330, 3);
INSERT INTO `knowledge_map` VALUES (332, 'Competency Management', 'Gatot Imam Sukoco', 330, 3);
INSERT INTO `knowledge_map` VALUES (333, 'Organisation & Culture', 'Nurdjaya', 330, 3);
INSERT INTO `knowledge_map` VALUES (334, 'Change Management', 'Nurdjaya', 330, 3);
INSERT INTO `knowledge_map` VALUES (340, 'Finance', NULL, 300, 2);
INSERT INTO `knowledge_map` VALUES (341, 'Budgeting', 'Laksono', 340, 3);
INSERT INTO `knowledge_map` VALUES (342, 'Tariff & Costing', 'Abdul Muis', 340, 3);
INSERT INTO `knowledge_map` VALUES (350, 'Planning', NULL, 300, 2);
INSERT INTO `knowledge_map` VALUES (351, 'Strategic & Program Planning', 'Meinanda K', 350, 3);
INSERT INTO `knowledge_map` VALUES (352, 'Resource Planning', 'Prasetiawan', 350, 3);
INSERT INTO `knowledge_map` VALUES (353, 'Process Management & Tools', 'Gatot Imam Sukoco', 350, 3);
INSERT INTO `knowledge_map` VALUES (354, 'Risk Management', 'Prasetiawan', 350, 3);
INSERT INTO `knowledge_map` VALUES (360, 'Performance Management', NULL, 300, 2);
INSERT INTO `knowledge_map` VALUES (361, 'Management System Evaluation', 'Nurdjaya', 360, 3);
INSERT INTO `knowledge_map` VALUES (362, 'Performance Measurement, Evaluation & Reporting', 'Luk Lu''ul Ilma', 360, 3);
INSERT INTO `knowledge_map` VALUES (370, 'Quality Management', NULL, 300, 2);
INSERT INTO `knowledge_map` VALUES (371, 'Quality System', 'Tyas Indah TH', 370, 3);
INSERT INTO `knowledge_map` VALUES (372, 'Innovation Management', 'Melani', 370, 3);
INSERT INTO `knowledge_map` VALUES (380, 'Partnership', NULL, 300, 2);
INSERT INTO `knowledge_map` VALUES (381, 'Joint Research & Development', 'Budi Supardiman', 380, 3);
INSERT INTO `knowledge_map` VALUES (382, 'Community Development', 'Andreas W.Y', 380, 3);
INSERT INTO `knowledge_map` VALUES (400, 'Personal Quality', NULL, 0, 1);
INSERT INTO `knowledge_map` VALUES (410, 'Presentation Skill', 'Kamariah L', 400, 2);
INSERT INTO `knowledge_map` VALUES (420, 'Problem & Decision Analysis', 'Lamhot Simamora', 400, 2);
INSERT INTO `knowledge_map` VALUES (430, 'Document Writing', 'Gunadi', 400, 2);
INSERT INTO `knowledge_map` VALUES (440, 'Communication Skill', 'Ari Wibowo', 400, 2);
INSERT INTO `knowledge_map` VALUES (500, 'Technology', '', 0, 1);
INSERT INTO `knowledge_map` VALUES (510, 'Core Network', '', 500, 2);
INSERT INTO `knowledge_map` VALUES (511, 'Optic Transmission', 'Lesmin Nainggolan', 510, 3);
INSERT INTO `knowledge_map` VALUES (512, 'Data Network', 'Fidar Aji Laksono', 510, 3);
INSERT INTO `knowledge_map` VALUES (513, 'Softswitch', 'Iwan Gunawan', 510, 3);
INSERT INTO `knowledge_map` VALUES (514, 'IMS', 'Angkoso', 510, 3);
INSERT INTO `knowledge_map` VALUES (515, 'MSCe', 'Azwir', 510, 3);
INSERT INTO `knowledge_map` VALUES (520, 'Access', '', 500, 2);
INSERT INTO `knowledge_map` VALUES (521, 'Broadband Wireline System', 'Ariyanto', 520, 3);
INSERT INTO `knowledge_map` VALUES (522, 'OSP & Operation Maintenance Support System', 'Sugeng', 520, 3);
INSERT INTO `knowledge_map` VALUES (523, 'Wireless', 'Denny Sukarman', 520, 3);
INSERT INTO `knowledge_map` VALUES (530, 'Service & Application', '', 500, 2);
INSERT INTO `knowledge_map` VALUES (531, 'Service & Application Paltform', 'Chandra T', 530, 3);
INSERT INTO `knowledge_map` VALUES (532, 'Service & Application Design', 'Fridh Zuriyadi', 530, 3);
INSERT INTO `knowledge_map` VALUES (533, 'Software & Application Engineering', 'Sigit H.P', 530, 3);
INSERT INTO `knowledge_map` VALUES (540, 'TMN', '', 500, 2);
INSERT INTO `knowledge_map` VALUES (541, 'Operation Support System', 'Bengris Pasaribu', 540, 3);
INSERT INTO `knowledge_map` VALUES (542, 'Business Support System', 'Guritno', 540, 3);
INSERT INTO `knowledge_map` VALUES (543, 'Customer Support System', 'Adi Permadi', 540, 3);
INSERT INTO `knowledge_map` VALUES (544, 'Network Management Protocol', 'Heru Irman', 540, 3);
INSERT INTO `knowledge_map` VALUES (545, 'Enterprise Application Interface', 'Sri Ponco', 540, 3);
INSERT INTO `knowledge_map` VALUES (546, 'Network Management Modeling', 'Ahmed Yasser', 540, 3);
INSERT INTO `knowledge_map` VALUES (550, 'Security & Numbering', '', 500, 2);
INSERT INTO `knowledge_map` VALUES (551, 'Network Security', 'Adi Permadi ', 550, 3);
INSERT INTO `knowledge_map` VALUES (552, 'Application Security', 'Asep Priyanto', 550, 3);
INSERT INTO `knowledge_map` VALUES (553, 'Revenue Assurance', 'Sovan Hadibowo', 550, 3);
INSERT INTO `knowledge_map` VALUES (554, 'Numbering System', 'Yusril Sini', 550, 3);
INSERT INTO `knowledge_map` VALUES (560, 'CPE', '', 500, 2);
INSERT INTO `knowledge_map` VALUES (561, 'Wireless', 'Joni Handoyo', 560, 3);
INSERT INTO `knowledge_map` VALUES (562, 'Wireline', 'Ariyanto', 560, 3);
INSERT INTO `knowledge_map` VALUES (570, 'Signaling', '', 500, 2);
INSERT INTO `knowledge_map` VALUES (571, 'Signaling VAS', 'Ibnu Alinursafa', 570, 3);
INSERT INTO `knowledge_map` VALUES (572, 'Signaling Core Network', 'Beni Triantono', 570, 3);
INSERT INTO `knowledge_map` VALUES (573, 'Signaling Access Network', 'Moch. Suharyanto', 570, 3);
INSERT INTO `knowledge_map` VALUES (580, 'Supporting Facilities', '', 500, 2);
INSERT INTO `knowledge_map` VALUES (581, 'Electrical', 'Suharjanto Mulyono', 580, 3);
INSERT INTO `knowledge_map` VALUES (582, 'Mechanical', 'Johanes Suharsono', 580, 3);
INSERT INTO `knowledge_map` VALUES (583, 'Civil', 'Suharjanto Mulyono', 580, 3);
INSERT INTO `knowledge_map` VALUES (590, 'Equipment Testing', '', 500, 2);
INSERT INTO `knowledge_map` VALUES (591, 'Mechanical & Electrical Measurement', 'Tri Susanto', 590, 3);
INSERT INTO `knowledge_map` VALUES (592, 'CPE & Switch Measurement', 'Nur''ain', 590, 3);
INSERT INTO `knowledge_map` VALUES (593, 'Transmission Measurement', 'Kusno Windarwanto', 590, 3);
INSERT INTO `knowledge_map` VALUES (594, 'Calibration Measurement', 'Setyo Hadi Hernowo', 590, 3);
INSERT INTO `knowledge_map` VALUES (595, 'Cable & Fiber Optiv Measurement', 'Nofrial', 590, 3);

-- --------------------------------------------------------

-- 
-- Table structure for table `loker`
-- 

CREATE TABLE `loker` (
  `id_loker` smallint(3) NOT NULL auto_increment,
  `nm_loker` varchar(100) default NULL,
  `acronym` varchar(4) default NULL,
  `id_top` smallint(3) default NULL,
  PRIMARY KEY  (`id_loker`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=165 ;

-- 
-- Dumping data for table `loker`
-- 

INSERT INTO `loker` VALUES (100, 'TELKOM RDC', 'RDC', 0);
INSERT INTO `loker` VALUES (101, 'Senior General Manager TELKOM RDC', 'SGM', 100);
INSERT INTO `loker` VALUES (110, 'Bidang Planning & Controlling', 'PNC', 100);
INSERT INTO `loker` VALUES (111, 'Bag. Planning & Business Development', 'PNBD', 110);
INSERT INTO `loker` VALUES (112, 'Bag. Quality Management', 'QM', 110);
INSERT INTO `loker` VALUES (113, 'Bag. Performance Management', 'PM', 110);
INSERT INTO `loker` VALUES (120, 'Bidang General Support', 'GS', 100);
INSERT INTO `loker` VALUES (121, 'Bag. Secretariate', 'SC', 120);
INSERT INTO `loker` VALUES (122, 'Bag. Logistic & Asset Management', 'LOG', 120);
INSERT INTO `loker` VALUES (123, 'Bag. User Relation', 'UREL', 120);
INSERT INTO `loker` VALUES (124, 'Bag. Data & IT Support', 'DITS', 120);
INSERT INTO `loker` VALUES (130, 'Bidang R&D of Infrastructure', 'RDI', 100);
INSERT INTO `loker` VALUES (131, 'Lab. Service Nodes', 'SN', 130);
INSERT INTO `loker` VALUES (132, 'Lab. Transmission', 'TR', 130);
INSERT INTO `loker` VALUES (133, 'Lab. Wireline Network', 'WNN', 130);
INSERT INTO `loker` VALUES (134, 'Lab. Wireless Network', 'WSN', 130);
INSERT INTO `loker` VALUES (135, 'Lab. Signalling & Integration', 'SNI', 130);
INSERT INTO `loker` VALUES (140, 'Bidang R&D of Network Management', 'RDNM', 100);
INSERT INTO `loker` VALUES (141, 'Lab. TMN', 'TMN', 140);
INSERT INTO `loker` VALUES (142, 'Lab. Security & Reliability', 'SNR', 140);
INSERT INTO `loker` VALUES (143, 'Lab. Technical Compliance', 'TC', 140);
INSERT INTO `loker` VALUES (144, 'Lab. QA Infrastructure', 'INF', 140);
INSERT INTO `loker` VALUES (145, 'Lab. QA CPE & Support', 'CPE', 140);
INSERT INTO `loker` VALUES (150, 'Bidang R&D of Service & Product', 'RDSP', 100);
INSERT INTO `loker` VALUES (151, 'Bag. Service & Product Planning', 'SNPP', 150);
INSERT INTO `loker` VALUES (152, 'Bag. Service Development', 'SD', 150);
INSERT INTO `loker` VALUES (153, 'Bag. Product Development', 'PD', 150);
INSERT INTO `loker` VALUES (154, 'Bag. Solution Enterprise', 'SE', 150);
INSERT INTO `loker` VALUES (160, 'Bidang Research of Business', 'ROB', 100);
INSERT INTO `loker` VALUES (161, 'Lab. Business Strategy Research', 'BSR', 160);
INSERT INTO `loker` VALUES (162, 'Lab. Business Performance', 'BP', 160);
INSERT INTO `loker` VALUES (163, 'Lab. Business Competitive', 'BC', 160);
INSERT INTO `loker` VALUES (164, 'Lab. Industrial Partnership', 'IP', 160);

-- --------------------------------------------------------

-- 
-- Table structure for table `mytable`
-- 

CREATE TABLE `mytable` (
  `key` smallint(2) default NULL,
  `room` varchar(6) default NULL,
  `start` datetime default NULL,
  `stop` datetime default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `mytable`
-- 

INSERT INTO `mytable` VALUES (1, 'Lounge', '2008-12-25 09:00:00', '2008-12-25 09:30:00');
INSERT INTO `mytable` VALUES (2, 'Lounge', '2008-12-25 11:00:00', '2008-12-25 11:15:00');
INSERT INTO `mytable` VALUES (3, 'Lounge', '2008-12-25 13:00:00', '2008-12-25 14:30:00');
INSERT INTO `mytable` VALUES (4, 'Lounge', '2008-12-25 14:30:00', '2008-12-25 14:45:00');

-- --------------------------------------------------------

-- 
-- Table structure for table `notification`
-- 

CREATE TABLE `notification` (
  `id_not` varchar(32) NOT NULL default '',
  `id_know` int(11) default NULL,
  `created` datetime default NULL,
  `subject` varchar(50) default NULL,
  `link` varchar(200) default NULL,
  `status` smallint(1) default '1',
  PRIMARY KEY  (`id_not`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `notification`
-- 

INSERT INTO `notification` VALUES ('ed513901e62a55e7e30bf6e47bf581a2', 1, '2009-05-04 09:56:48', 'Request Sharing', NULL, 1);
INSERT INTO `notification` VALUES ('190cb9cbe0db6e10b25f3871438ee6af', 2, '2009-05-04 09:59:58', 'Request Sharing', 'http://localhost/km/mgm_sharing.php?id=2&mn=12', 1);
INSERT INTO `notification` VALUES ('c35753158191879c6ecf11f35018d54f', 3, '2009-05-04 11:23:08', 'Request Sharing', NULL, 1);
INSERT INTO `notification` VALUES ('d1f1055296be6e2ad8936e8681fe5475', 4, '2009-05-04 17:03:03', 'Request Sharing', 'http://localhost/km/mgm_sharing.php?id=4&mn=12', 1);
INSERT INTO `notification` VALUES ('fb495cc48bd98e69223adf97d60ee95f', 6, '2009-05-05 14:12:57', 'Request Sharing', 'http://localhost/km/mgm_sharing.php?id=6&mn=12', 1);
INSERT INTO `notification` VALUES ('5cd134b5ffd51d01957dde1af1ab6889', 3, '2009-05-06 12:06:03', 'Request Sharing', NULL, 1);
INSERT INTO `notification` VALUES ('6575cffe724e1b7017b952cf84be3dc5', 3, '2009-05-06 13:53:04', 'Request to Attend', NULL, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `notification_4nik`
-- 

CREATE TABLE `notification_4nik` (
  `id_not` varchar(32) NOT NULL,
  `nik` int(6) NOT NULL,
  PRIMARY KEY  (`id_not`,`nik`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `notification_4nik`
-- 

INSERT INTO `notification_4nik` VALUES ('5cd134b5ffd51d01957dde1af1ab6889', 730373);
INSERT INTO `notification_4nik` VALUES ('6575cffe724e1b7017b952cf84be3dc5', 730373);

-- --------------------------------------------------------

-- 
-- Table structure for table `profile`
-- 

CREATE TABLE `profile` (
  `id_profile` smallint(1) NOT NULL auto_increment,
  `nm_profile` varchar(13) default NULL,
  PRIMARY KEY  (`id_profile`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `profile`
-- 

INSERT INTO `profile` VALUES (1, 'Administrator');
INSERT INTO `profile` VALUES (2, 'Committee');
INSERT INTO `profile` VALUES (3, 'Common User');

-- --------------------------------------------------------

-- 
-- Table structure for table `rapor_bidang`
-- 

CREATE TABLE `rapor_bidang` (
  `year` smallint(4) NOT NULL,
  `id_bidang` smallint(3) NOT NULL,
  `total_point` smallint(4) default NULL,
  PRIMARY KEY  (`year`,`id_bidang`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `rapor_bidang`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `rapor_individu`
-- 

CREATE TABLE `rapor_individu` (
  `year` smallint(4) NOT NULL,
  `nik` int(6) NOT NULL,
  `total_point` smallint(3) default NULL,
  PRIMARY KEY  (`year`,`nik`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `rapor_individu`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `req_to_attend`
-- 

CREATE TABLE `req_to_attend` (
  `id` int(11) NOT NULL auto_increment,
  `id_know` int(11) default NULL,
  `email` varchar(50) default NULL,
  `created` datetime default NULL,
  `id_status` smallint(1) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `req_to_attend`
-- 

INSERT INTO `req_to_attend` VALUES (1, 3, 'fridh@telkom.co.id', '2009-05-05 11:10:00', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `schedule`
-- 

CREATE TABLE `schedule` (
  `id_know` int(11) NOT NULL,
  `t_mulai` datetime default NULL,
  `t_akhir` datetime default NULL,
  `durasi` int(3) default NULL,
  `statusnya` varchar(5) default NULL,
  PRIMARY KEY  (`id_know`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `schedule`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `sharing_act_ext`
-- 

CREATE TABLE `sharing_act_ext` (
  `id` int(11) NOT NULL auto_increment,
  `id_know` int(11) default NULL,
  `email` varchar(100) default NULL,
  `attend` smallint(1) default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `sharing_act_ext`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `sharing_activity`
-- 

CREATE TABLE `sharing_activity` (
  `id_know` int(11) NOT NULL,
  `nik` int(6) NOT NULL,
  `id_confirm` smallint(1) default NULL,
  `id_inv_status` smallint(1) default NULL,
  `attend` smallint(1) default '0',
  `poin` int(4) default NULL,
  PRIMARY KEY  (`id_know`,`nik`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `sharing_activity`
-- 

INSERT INTO `sharing_activity` VALUES (1, 740111, 1, 1, 1, 10);
INSERT INTO `sharing_activity` VALUES (1, 602217, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (1, 570432, 1, 3, 1, 2);
INSERT INTO `sharing_activity` VALUES (1, 631686, 1, 3, 1, 2);
INSERT INTO `sharing_activity` VALUES (1, 632998, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (1, 650675, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (1, 651196, 1, 3, 1, 2);
INSERT INTO `sharing_activity` VALUES (1, 660152, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (1, 660229, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (1, 670132, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (1, 680151, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (1, 680162, 2, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (1, 680177, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (1, 680596, 2, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (1, 720079, 3, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (1, 720328, 1, 3, 1, 2);
INSERT INTO `sharing_activity` VALUES (1, 730052, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (1, 730079, 1, 3, 1, 2);
INSERT INTO `sharing_activity` VALUES (1, 730338, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (1, 760054, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (1, 790102, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (3, 710439, 1, 1, 1, 10);
INSERT INTO `sharing_activity` VALUES (3, 602217, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (3, 570998, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (3, 620132, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (3, 642129, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (3, 670115, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (3, 680163, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (3, 720101, 1, 3, 1, 2);
INSERT INTO `sharing_activity` VALUES (3, 730050, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (3, 730170, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (3, 730569, 1, 3, 1, 2);
INSERT INTO `sharing_activity` VALUES (3, 740138, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (3, 740211, 1, 3, 1, 2);
INSERT INTO `sharing_activity` VALUES (3, 750052, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (3, 770081, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730365, 1, 1, 1, 10);
INSERT INTO `sharing_activity` VALUES (5, 570998, 1, 3, 1, 2);
INSERT INTO `sharing_activity` VALUES (5, 620132, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 642129, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 670115, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 680163, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 710439, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 720101, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730050, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730170, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730569, 1, 3, 1, 2);
INSERT INTO `sharing_activity` VALUES (5, 740138, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 740211, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 750052, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 770081, 1, 3, 1, 2);
INSERT INTO `sharing_activity` VALUES (5, 541255, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 542312, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 580267, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 581066, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 581123, 1, 3, 1, 2);
INSERT INTO `sharing_activity` VALUES (5, 590408, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 590471, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 590859, 1, 3, 1, 2);
INSERT INTO `sharing_activity` VALUES (5, 591707, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 591732, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 600562, 1, 3, 1, 2);
INSERT INTO `sharing_activity` VALUES (5, 601400, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 601421, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 601644, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 610785, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 611130, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 620884, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 621513, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 621527, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 623089, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 630030, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 630685, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 641587, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 641627, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 641671, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 650265, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 650719, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 650816, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 651176, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 660454, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730088, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 740073, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 550881, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 550893, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 580084, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 581170, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 590452, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 632999, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 633078, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 641438, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 651327, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 660483, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 670026, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 670028, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 680028, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 710402, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 710458, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 710501, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 720208, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 720254, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 720286, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 720348, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 720416, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 720419, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730055, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730237, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730312, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730420, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730481, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730590, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 740191, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 740207, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 750031, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 750053, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 760047, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 810097, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 830070, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 850077, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 560345, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 580286, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 632964, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 632980, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 640934, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 642113, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 660060, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 680174, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 690604, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 710400, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 720154, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 720214, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 720346, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 720598, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730255, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730351, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730373, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730398, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730402, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730448, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730478, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730517, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730537, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730568, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730576, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 730600, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 740086, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 740283, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 750046, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 840103, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 850114, NULL, 3, 0, NULL);
INSERT INTO `sharing_activity` VALUES (3, 730373, 1, 4, 0, NULL);
INSERT INTO `sharing_activity` VALUES (5, 740111, 1, 4, 1, 2);
INSERT INTO `sharing_activity` VALUES (3, 740111, 1, 4, 1, 2);

-- --------------------------------------------------------

-- 
-- Table structure for table `subject`
-- 

CREATE TABLE `subject` (
  `id_subject` smallint(2) NOT NULL auto_increment,
  `nm_subject` varchar(50) default NULL,
  `message` text,
  PRIMARY KEY  (`id_subject`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `subject`
-- 

INSERT INTO `subject` VALUES (1, 'Request Sharing', 'This is request from ');
INSERT INTO `subject` VALUES (2, 'Request Sharing', 'Your request ');
INSERT INTO `subject` VALUES (3, 'Closing Task', 'Please close your task.');
INSERT INTO `subject` VALUES (4, 'Request to Attend', '');
INSERT INTO `subject` VALUES (5, 'Report', 'Your Report ');

-- --------------------------------------------------------

-- 
-- Table structure for table `upload`
-- 

CREATE TABLE `upload` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  `type` varchar(30) NOT NULL default '',
  `size` int(11) NOT NULL default '0',
  `path` varchar(200) NOT NULL default '',
  `randomkey` varchar(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `upload`
-- 

INSERT INTO `upload` VALUES (1, 'KMORE_Proses.pdf', 'application/pdf', 38759, '/AppServ/www/km/upload/KMORE_Proses.pdf', '7829503Fz');

-- --------------------------------------------------------

-- 
-- Table structure for table `user`
-- 

CREATE TABLE `user` (
  `nik` int(6) NOT NULL,
  `nama` varchar(100) default NULL,
  `band` varchar(3) default NULL,
  `posisi` varchar(100) default NULL,
  `id_bidang` smallint(3) default NULL,
  `id_loker` smallint(3) default NULL,
  `email` varchar(100) default NULL,
  `id_profile` smallint(1) default NULL,
  `active` smallint(1) default '1',
  PRIMARY KEY  (`nik`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `user`
-- 

INSERT INTO `user` VALUES (540014, 'Suharjanto Muljono', NULL, NULL, 140, 140, 'harjanto@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (541255, 'Entit Mulyono Burhan Ibrahim', NULL, NULL, 120, 122, 'mulyonobi@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (542040, 'Suyono', NULL, NULL, 140, 140, 'su_yono@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (542312, 'Agus Wahyudin', NULL, NULL, 120, 122, 'a_wahyudin@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (550579, 'Teguh Semedi', NULL, NULL, 140, 143, 'tsemedi@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (550764, 'Sugiyanto', NULL, NULL, 140, 144, 'sugiyanto@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (550881, 'Athanasius Sudibyo', NULL, NULL, 130, 135, 'byo@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (550893, 'Joni Handoyo', NULL, NULL, 130, 130, 'handoyo@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (560345, 'Sofyan Achmad Basuki', NULL, NULL, 150, 151, 'sofyanab@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (560481, 'Rahmadi', NULL, NULL, 120, 122, 'rahmadi@telkom.co.id', 3, 0);
INSERT INTO `user` VALUES (560842, 'Eddy Hartono', NULL, NULL, 140, 144, 'eddi h@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (570432, 'Muljanto', NULL, NULL, 160, 160, 'muljanto@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (570653, 'Mohamad Husein', NULL, NULL, 140, 145, 'husen@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (570998, 'Luciana Djajadiredja', NULL, NULL, 110, 110, 'luciana@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (580084, 'Sugeng', NULL, NULL, 130, 130, 'sugeng@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (580092, 'Agus Purwanto', NULL, NULL, 140, 143, 'purwanto_83@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (580249, 'Yohanes Suharsono', NULL, NULL, 140, 140, 'suharsono@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (580267, 'Albiden Radwin Yoseph Samosir', NULL, NULL, 120, 122, 'samco@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (580286, 'Edy Harijanto', NULL, NULL, 150, 152, 'eha@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (581066, 'Marcus Suratman', NULL, NULL, 120, 121, 'ratman@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (581123, 'Sumini Lukman', NULL, NULL, 120, 123, 'sumi@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (581170, 'Bambang Soekanto', NULL, NULL, 130, 130, 'bsoekanto@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (590071, 'I G. Kade Bambang H.P.', NULL, NULL, 140, 140, 'kade@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (590408, 'Linda Avianti', NULL, NULL, 120, 121, 'linda_44@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (590452, 'Widodo', NULL, NULL, 130, 134, 'wi_dodo@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (590460, 'Nofrial', NULL, NULL, 140, 144, 'nofrial@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (590471, 'I Ketut Yadnya', NULL, NULL, 120, 122, 'yadnya@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (590859, 'Ervin Entjep Rachmat', NULL, NULL, 120, 123, 'ervin@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (591707, 'Martini Pudjiastuti', NULL, NULL, 120, 120, 'martini@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (591732, 'Widi Rusmiyanta', NULL, NULL, 120, 121, 'widi_r@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (600562, 'Sri Wiwiek Hendhayani', NULL, NULL, 120, 121, 'wiwiek@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (601400, 'Ahmad Ropik', NULL, NULL, 120, 122, 'aropik@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (601421, 'Achmad Wahyu Hidayat', NULL, NULL, 120, 122, 'awh@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (601644, 'Iskandar', NULL, NULL, 120, 121, 'h_iskandar@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (602093, 'Lidia Ratih Nurulita', NULL, NULL, 120, 123, 'lidia@telkom.co.id', 3, 0);
INSERT INTO `user` VALUES (602216, 'Kusno Windarwanto', NULL, NULL, 140, 140, 'windarwanto@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (602217, 'Mustapa Wangsaatmadja', NULL, NULL, 100, 101, 'mustapa@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (610305, 'Suhardi Laksono', NULL, NULL, 140, 143, 'slaksono@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (610306, 'Agus Trio', NULL, NULL, 140, 143, 'trio@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (610785, 'Mirawati', NULL, NULL, 120, 121, 'mira@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (611130, 'Yusuf Makhmuddin', NULL, NULL, 120, 120, 'yumas@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (620132, 'Abdul Muis', NULL, NULL, 110, 111, 'moeis@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (620776, 'Saiful Mansyur', NULL, NULL, 150, 150, 'saiful_m@telkom.co.id', 3, 0);
INSERT INTO `user` VALUES (620784, 'Setyo Hadi Hernowo', NULL, NULL, 140, 140, 'sehadi@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (620884, 'Wawan Sugiwan', NULL, NULL, 120, 122, 'sugiwan@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (621513, 'Ichiode Budisetyanto', NULL, NULL, 120, 123, 'ichiode@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (621527, 'Toto Sudarto', NULL, NULL, 120, 122, 'totosudarto@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (623089, 'Bambang Siswanto', NULL, NULL, 120, 123, 'bambang_sis@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (630030, 'Mariani Stephani', NULL, NULL, 120, 121, 'mariani@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (630685, 'Stepanus Sumardjono', NULL, NULL, 120, 124, 'stevans@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (630741, 'Bonifacius Widodo', NULL, NULL, 110, 113, 'boni_w@telkom.co.id', 3, 0);
INSERT INTO `user` VALUES (631686, 'Anna Lumumba', NULL, NULL, 160, 162, 'anna_l@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (632964, 'Rudi Sunarno', NULL, NULL, 150, 150, 'rudi@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (632980, 'Ign.Wiseto P. Agung', NULL, NULL, 150, 150, 'wiseto@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (632998, 'Rahadian Krishna Sundara', NULL, NULL, 160, 160, 'krishna@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (632999, 'Denny Sukarman', NULL, NULL, 130, 134, 'd_sukarman@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (633070, 'Bilpen Nainggolan', NULL, NULL, 140, 140, 'bil@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (633078, 'Christian Sulingalo', NULL, NULL, 130, 130, 'chsallo@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (633086, 'Bengris Pasaribu', NULL, NULL, 140, 141, 'pasaribu@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (640934, 'Roessobiyatno', NULL, NULL, 150, 150, 'roesso@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (641438, 'Akhmad Syauqi', NULL, NULL, 130, 133, 'syauqi@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (641541, 'Hariyono', NULL, NULL, 140, 142, 'hariyono@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (641587, 'Lili Tasli', NULL, NULL, 120, 124, 'lie@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (641627, 'Ujianto Panenjar', NULL, NULL, 120, 121, 'ujianto@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (641671, 'Wiyono', NULL, NULL, 120, 122, 'wiy_ono@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (641963, 'Agus Salim', NULL, NULL, 140, 140, 'salim@telkom.co.id', 3, 0);
INSERT INTO `user` VALUES (641967, 'Guritno Dwi S.', NULL, NULL, 140, 140, 'guritno64@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (641984, 'Nur''ain Syaiful Toharoh', NULL, NULL, 140, 145, 'nurain@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (642091, 'Setyo Budi Agung', NULL, NULL, 150, 150, 'setyo_ba@telkom.co.id', 3, 0);
INSERT INTO `user` VALUES (642112, 'Yusril Sini', NULL, NULL, 140, 142, 'sini@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (642113, 'Sjamsurjana', NULL, NULL, 150, 152, 'syam@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (642129, 'Nurdjaja R.', NULL, NULL, 110, 113, 'nurdjaja@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (650265, 'Yudi Tri Jayadi', NULL, NULL, 120, 124, 'ytri@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (650469, 'Rahardian Perdana Mulya', NULL, NULL, 120, 123, 'peppy@telkom.co.id', 3, 0);
INSERT INTO `user` VALUES (650675, 'Sentot Hery Suseno', NULL, NULL, 160, 161, 'sentot_hs@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (650719, 'Hary Sugiarso', NULL, NULL, 120, 124, 'haes@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (650816, 'Dang Kartiwa', NULL, NULL, 120, 123, 'dank@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (651176, 'Asep Priyanto', NULL, NULL, 120, 124, 'asep_p@telkom.co.id', 1, 1);
INSERT INTO `user` VALUES (651196, 'Faisal Baharuddin', NULL, NULL, 160, 162, 'faisal_b@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (651200, 'Sontang Hutapea', NULL, NULL, 140, 145, 'sontang@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (651327, 'Edy Siswanto', NULL, NULL, 130, 130, '', 3, 1);
INSERT INTO `user` VALUES (660060, 'Mochamad Wahyu Nuzul Karim', NULL, NULL, 150, 152, 'wahyu@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (660152, 'Bambang Achiranto', NULL, NULL, 160, 164, 'achir@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (660167, 'Rizki Hadiansyah', NULL, NULL, 140, 144, 'rizki@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (660229, 'Fentiani', NULL, NULL, 160, 163, 'fenti@telkom.co.id', 1, 1);
INSERT INTO `user` VALUES (660454, 'Kuatin', NULL, NULL, 120, 121, 'kuatin@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (660483, 'Eddy Setiawan', NULL, NULL, 130, 134, 'eddysetiawan@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (670026, 'Rizki Firman', NULL, NULL, 130, 135, 'rizki_f@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (670028, 'Mahyar Koswara', NULL, NULL, 130, 133, 'mahyar@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (670115, 'Eddy Yuniarto', NULL, NULL, 110, 113, 'eddy_y@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (670132, 'Soendojoadi', NULL, NULL, 160, 161, 'soen@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (680028, 'Iwan Gunawan', NULL, NULL, 130, 130, 'iwang@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (680151, 'Syahroni Tua', NULL, NULL, 160, 164, 'syahronitua@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (680162, 'Lamhot Sinta Parulian Simamora', NULL, NULL, 160, 161, 'simamora@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (680163, 'Budi Supardiman', NULL, NULL, 110, 112, 'b_supardiman@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (680174, 'Dinoor Susatijo', NULL, NULL, 150, 154, 'dinoor@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (680177, 'Johanes Adi Purnama Putra', NULL, NULL, 160, 164, 'johanes_adi@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (680596, 'Ratih Ruffianti', NULL, NULL, 160, 162, 'ruffianti@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (690604, 'Aji Widodo', NULL, NULL, 150, 152, 'aji_w@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (710400, 'Zakariah', NULL, NULL, 150, 151, 'arie212@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (710402, 'Karno Budiono', NULL, NULL, 130, 132, 'karno@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (710439, 'Laksono Sugeng Santoso', NULL, NULL, 110, 111, 'laksono_ss@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (710458, 'Hazim Ahmadi', NULL, NULL, 130, 134, 'azim@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (710501, 'Randi Permana', NULL, NULL, 130, 131, 'randi@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (720079, 'Riefna Azwita', NULL, NULL, 160, 163, 'wita@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (720080, 'Patricia Eugene Gaspersz', NULL, NULL, 130, 134, 'patty@telkom.co.id', 3, 0);
INSERT INTO `user` VALUES (720088, 'Ahmed Yasser', NULL, NULL, 140, 140, 'yasser@telkom.co.id', 1, 1);
INSERT INTO `user` VALUES (720101, 'Prasetiawan', NULL, NULL, 110, 111, 'prasetiawan@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (720154, 'Samudra Prasetio', NULL, NULL, 150, 153, 'samudra@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (720208, 'Mochammad Soeharijanto', NULL, NULL, 130, 135, 'mshyanto@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (720214, 'Sony Ari Yuniarto', NULL, NULL, 150, 154, 'yuniarto@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (720254, 'Gunadi Dwi Hantoro', NULL, NULL, 130, 134, 'gunadi_dh@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (720270, 'Gede Astawa', NULL, NULL, 140, 140, 'astawa@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (720272, 'Ato Riyanto', NULL, NULL, 160, 161, 'ato@telkom.co.id', 3, 0);
INSERT INTO `user` VALUES (720286, 'Konang Prihandoko', NULL, NULL, 130, 130, '', 3, 1);
INSERT INTO `user` VALUES (720291, 'Edi Witjara', NULL, NULL, 130, 132, 'witj@telkom.co.id', 3, 0);
INSERT INTO `user` VALUES (720292, 'Hadi Hariyanto', NULL, NULL, 120, 122, 'hadiy@telkom.co.id', 3, 0);
INSERT INTO `user` VALUES (720328, 'Agung Hendriyanto', NULL, NULL, 160, 163, 'goeng@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (720346, 'Anna Mulyani', NULL, NULL, 150, 151, 'anna_m@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (720348, 'Akhmad Ludfy', NULL, NULL, 130, 132, 'ludfy@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (720416, 'Fidar Adjie Laksono', NULL, NULL, 130, 130, 'fidar@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (720419, 'Lesmin Nainggolan', NULL, NULL, 130, 132, 'esmint@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (720592, 'Adnan Sudrajat', NULL, NULL, 140, 145, 'adnans@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (720598, 'Triansoni', NULL, NULL, 150, 153, 'triansoni@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730050, 'Tyas Indah Twi Handayani', NULL, NULL, 110, 112, 'tyas_ith@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730052, 'Henry Setiawan Wyatno', NULL, NULL, 160, 160, 'henry@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730055, 'Ahmad Arif Rahman', NULL, NULL, 130, 133, 'arif_r@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730079, 'Kamariah Latief', NULL, NULL, 160, 161, 'rial@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730088, 'Elfri Jufri', NULL, NULL, 120, 123, 'elfri@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730125, 'Mohammad Sovan Hadibowo', NULL, NULL, 140, 143, 'opang@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730170, 'Gatot Imam Sukoco', NULL, NULL, 110, 111, 'gatotimamsukoco@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730237, 'Agnesia Candra Sulyani', NULL, NULL, 130, 132, 'usi@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730255, 'Denny Permana', NULL, NULL, 150, 154, 'denny@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730299, 'Ida Bagus Putu Ariartha', NULL, NULL, 140, 140, 'ariartha@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730312, 'Daduk Merdika Mansur', NULL, NULL, 130, 134, '', 3, 1);
INSERT INTO `user` VALUES (730338, 'Paulus Pandu Parlaungan Hutagaol', NULL, NULL, 160, 163, 'hutagaol@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730351, 'Sri Maizawati', NULL, NULL, 150, 154, 'ijak@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730364, 'Darso', NULL, NULL, 140, 142, 'darso@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730365, 'Anung Asmoro', NULL, NULL, 150, 152, 'anung@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730373, 'Fridh Zurriyadi Ridwan', NULL, NULL, 150, 150, 'fridh@telkom.co.id', 1, 1);
INSERT INTO `user` VALUES (730389, 'Tri Susanto', NULL, NULL, 140, 145, 'trissto@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730398, 'Hariyo Santoso', NULL, NULL, 150, 150, 'hariyo@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730402, 'F.X Ari Wibowo', NULL, NULL, 150, 151, 'ari_wibowo@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730420, 'Ariyanto', NULL, NULL, 130, 133, 'aryanto@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730447, 'Hezekieli Gulo', NULL, NULL, 140, 142, 'k-gulo@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730448, 'Eka Kelana', NULL, NULL, 150, 150, 'eka_k@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730478, 'Sigit Hadi Prayoga', NULL, NULL, 150, 150, 'sigit_hp@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730481, 'Silahuddin Sumantri', NULL, NULL, 130, 131, 's_tri@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730517, 'Gati Cahyo Handoyo', NULL, NULL, 150, 153, 'gati@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730537, 'Taufik Zamzami', NULL, NULL, 150, 154, 'taufikz@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730546, 'Yovita Misriga', NULL, NULL, 140, 143, 'yovi@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730560, 'Marindra Bawono', NULL, NULL, 130, 131, 'marindra@telkom.co.id', 3, 0);
INSERT INTO `user` VALUES (730568, 'Zen Agus Wahyudin', NULL, NULL, 150, 154, 'zen_udin@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730569, 'Carli', NULL, NULL, 110, 113, 'carli@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730576, 'Wulan Tri Wahyudi', NULL, NULL, 150, 154, 'woel@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730589, 'Sri Ponco Kisworo', NULL, NULL, 140, 141, 'ponco_k@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730590, 'Dian Agung Nugroho', NULL, NULL, 130, 135, 'agung_n@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (730600, 'Deni Risnandar', NULL, NULL, 150, 153, 'deni-r@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (740073, 'Lasmi Ivawaty', NULL, NULL, 120, 124, 'lasmi_i@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (740079, 'Arief Hamdani Gunawan', NULL, NULL, 120, 122, 'hamdani2@telkom.co.id', 3, 0);
INSERT INTO `user` VALUES (740081, 'Andri Qiantori', NULL, NULL, 150, 152, 'qiantori@telkom.co.id', 3, 0);
INSERT INTO `user` VALUES (740086, 'Chandra Tamrin', NULL, NULL, 150, 150, 'chandrat@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (740111, 'Andreas Widiasmono Yanuardi', NULL, NULL, 160, 164, 'andreas_w@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (740131, 'Yudha Indah Prihatini', NULL, NULL, 140, 142, 'prihat@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (740138, 'Luk lu''ul Ilma', NULL, NULL, 110, 113, 'luk@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (740191, 'M. Azwir', NULL, NULL, 130, 131, 'mazwir@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (740207, 'Beny Triantono', NULL, NULL, 130, 135, 'beny_t@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (740211, 'Hariyanto', NULL, NULL, 110, 112, 'hriyanto@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (740247, 'Heru Irman', NULL, NULL, 140, 141, 'heruir@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (740277, 'Lukman Hakim Abdul Rauf', NULL, NULL, 130, 133, 'lukman_h@telkom.co.id', 3, 0);
INSERT INTO `user` VALUES (740283, 'Rakhman Imansyah', NULL, NULL, 150, 153, 'rakhman@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (740285, 'Romzi Imron Rosidi', NULL, NULL, 140, 141, 'romzy@telkom.co.id', 3, 0);
INSERT INTO `user` VALUES (740287, 'Rudy Harinugroho', NULL, NULL, 160, 162, 'rudyhari@telkom.co.id', 3, 0);
INSERT INTO `user` VALUES (740293, 'Tri Ayuningsih', NULL, NULL, 140, 143, 'tri_ayu@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (740299, 'Wahyu Novian Condro Murwanto', NULL, NULL, 140, 142, 'wnovian@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (750031, 'Ibnu Alinursafa', NULL, NULL, 130, 135, 'ibnua@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (750034, 'Adi Permadi', NULL, NULL, 140, 140, 'adigeb@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (750046, 'Indri Sonwaskito', NULL, NULL, 150, 153, 'indrison@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (750052, 'Meinanda Kurniawan', NULL, NULL, 110, 111, 'meinanda@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (750053, 'Angkoso Suryocahyono', NULL, NULL, 130, 131, 'angkoso@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (760047, 'Bagus Budi Santoso', NULL, NULL, 130, 131, 'bagus_bs@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (760054, 'Christina Novitarini', NULL, NULL, 160, 161, 'christin@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (770081, 'Melani Anugrahani', NULL, NULL, 110, 112, 'melani@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (790044, 'Dyah Shinta Tri Wulandari', NULL, NULL, 160, 162, 'dyah_shinta@telkom.co.id', 3, 0);
INSERT INTO `user` VALUES (790102, 'Dianing Murti Pramesti', NULL, NULL, 160, 162, 'dian_pramesti@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (810097, 'Retno Wulansari', NULL, NULL, 130, 133, 'r_wulansari@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (820043, 'Zul Ramadhan', NULL, NULL, 140, 145, 'zul_ramadhan@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (830070, 'Mahardi Prabowo', NULL, NULL, 130, 134, '', 3, 1);
INSERT INTO `user` VALUES (840103, 'Widhiantantri Saraswati', NULL, NULL, 150, 152, 'widhia@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (840138, 'Detriana Margita Sari', NULL, NULL, 140, 144, '', 3, 1);
INSERT INTO `user` VALUES (840148, 'Eliandri Shintani Wulandari', NULL, NULL, 140, 145, '', 3, 1);
INSERT INTO `user` VALUES (850077, 'David Gunawan', NULL, NULL, 130, 131, 'david@telkom.co.id', 3, 1);
INSERT INTO `user` VALUES (850114, 'Lely Triastiti', NULL, NULL, 150, 154, 'leltri@telkom.co.id', 3, 1);
