UPDATE sharing_activity SET id_confirm='1' WHERE id_know='3' AND nik='730373';

SELECT a.*, b.*, c.nama, c.id_bidang, d.nm_loker 
FROM sharing_activity a JOIN knowledge b ON a.id_know=b.id_know JOIN USER c ON a.nik=c.nik JOIN loker d ON c.id_bidang=d.id_loker 
WHERE id_inv_status='4';

SELECT * FROM sharing_activity WHERE id_know='3' AND nik='730373';

# Show request to attend
SELECT a.*, b.id_know, b.judul, c.nama, c.id_bidang, d.nm_loker, e.id_not, f.created AS datereq  
FROM sharing_activity a JOIN knowledge b ON a.id_know=b.id_know JOIN USER c ON a.nik=c.nik JOIN loker d ON c.id_bidang=d.id_loker 
JOIN notification_4nik e ON a.nik=e.nik JOIN notification f ON e.id_not=f.id_not
WHERE a.id_inv_status='4' AND a.id_confirm IS NULL;

---

SELECT a.*, b.nm_loker FROM USER a 
JOIN loker b ON a.id_bidang=b.id_loker
WHERE nik = (SELECT nik FROM sharing_activity WHERE id_know='3' AND nik='730373');

SELECT b.nm_loker,COUNT(*) FROM USER a JOIN loker b ON a.id_bidang=b.id_loker GROUP BY id_bidang;

SELECT a.nik AS niknya, b.nama, SUM(a.poin) AS nilai, c.nm_loker 
FROM sharing_activity a JOIN USER b ON a.nik=b.nik JOIN loker c ON b.id_bidang=c.id_loker 
GROUP BY a.nik HAVING SUM(poin) IS NOT NULL ORDER BY nilai DESC;
SELECT a.nik AS niknya, b.nama, SUM(a.poin) AS nilai, c.nm_loker FROM sharing_activity a JOIN USER b ON a.nik=b.nik JOIN loker c ON b.id_bidang=c.id_loker GROUP BY a.nik ORDER BY nilai DESC

---

SELECT a.nik AS niknya, b.nama, c.nm_loker, SUM(a.poin) AS nilai 
FROM sharing_activity a JOIN USER b ON a.nik=b.nik JOIN loker c ON b.id_bidang=c.id_loker 
WHERE a.nik='740111' 
GROUP BY a.nik HAVING SUM(poin) IS NOT NULL ORDER BY nilai DESC;

UPDATE sharing_activity SET POINT=2 WHERE POINT=5;

SELECT a.*, b.nama AS submitter, c.nama AS speaker, d.nm_map 
FROM knowledge a JOIN USER b ON a.nik=b.nik JOIN USER c ON a.nik=c.nik JOIN knowledge_map d ON a.id_map=d.id_map 
WHERE a.id_know='1';
SELECT a.id_inv_status,a.nik,b.nama,c.nm_loker FROM sharing_activity a JOIN USER B ON a.nik=b.nik JOIN loker c ON b.id_bidang=c.id_loker 
WHERE id_know='1' AND attend=1 ORDER BY a.id_inv_status,c.id_loker,b.nik;

---

SELECT id_know,t_mulai,t_akhir FROM knowledge 
WHERE req_status='Open' AND report_status='0' 
AND (t_mulai>2009-05-08 08:30:00 AND t_mulai<2009-05-08 10:30:00) OR (t_akhir>2009-05-08 08:30:00 AND t_akhir<2009-05-08 10:30:00) LIMIT 1 ;

SELECT kunci, mulai, akhir FROM MyTable 
WHERE room = 'Lounge' AND ( mulai > '2008-12-25 09:29:59' AND mulai < '2008-12-25 11:00:00' ) OR 
( akhir > '2008-12-25 09:29:59' AND akhir < '2008-12-25 11:00:00' ) LIMIT 1;