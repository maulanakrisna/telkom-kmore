/*
SQLyog Community Edition- MySQL GUI v8.05 
MySQL - 5.0.22-community-nt-log : Database - kmore
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`kmore` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `kmore`;

/*Table structure for table `sharing_notes` */

DROP TABLE IF EXISTS `sharing_notes`;

CREATE TABLE `sharing_notes` (
  `id_know` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `nik` int(6) default NULL,
  `notes` text,
  PRIMARY KEY  (`id_know`,`created`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `sharing_notes` */

insert  into `sharing_notes`(`id_know`,`created`,`nik`,`notes`) values (6,'2009-05-08 15:40:27',730373,'Ada apa ini, ada apa ini?'),(6,'2009-05-08 16:11:39',660229,'Tes, satu dua tiga empat...\r\n1. Pertama\r\n2. Kedua\r\n3. Setelah Pertama dan Kedua');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
